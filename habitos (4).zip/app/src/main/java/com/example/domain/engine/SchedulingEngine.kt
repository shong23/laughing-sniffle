package com.example.domain.engine

import com.example.data.local.entity.HabitEntity

object SchedulingEngine {

    fun isHabitDueOnDate(habit: HabitEntity, isoDate: String): Boolean {
        if (habit.archived) return false

        // Habit only starts on or after its creation start date
        val start = habit.effectiveStartDate
        if (start.isNotBlank() && isoDate < start) {
            return false
        }

        val dayOfWeek = DateUtils.getDayOfWeek(isoDate)
        val dayCode = DateUtils.getDayOfWeekCode(isoDate)

        return when (habit.frequencyType) {
            "DAILY" -> true
            "WEEKDAYS" -> dayOfWeek in 1..5
            "WEEKENDS" -> dayOfWeek in 6..7
            "SPECIFIC_DAYS" -> {
                val configuredDays = habit.frequencyConfig
                    .split(",")
                    .map { it.trim().uppercase() }
                configuredDays.contains(dayCode)
            }
            "X_PER_WEEK" -> true // Open to log on any day
            "X_PER_MONTH" -> true // Open to log on any day
            else -> true
        }
    }

    fun getFrequencyDisplay(habit: HabitEntity): String {
        return when (habit.frequencyType) {
            "DAILY" -> "Every day"
            "WEEKDAYS" -> "Weekdays (Mon–Fri)"
            "WEEKENDS" -> "Weekends"
            "SPECIFIC_DAYS" -> {
                val days = habit.frequencyConfig.split(",").map { it.trim().uppercase() }
                if (days.size == 7) "Every day"
                else days.joinToString(", ") { codeToShort(it) }
            }
            "X_PER_WEEK" -> "${habit.frequencyConfig}x per week"
            "X_PER_MONTH" -> "${habit.frequencyConfig}x per month"
            else -> "Daily"
        }
    }

    private fun codeToShort(code: String): String {
        return when (code) {
            "MON" -> "Mon"
            "TUE" -> "Tue"
            "WED" -> "Wed"
            "THU" -> "Thu"
            "FRI" -> "Fri"
            "SAT" -> "Sat"
            "SUN" -> "Sun"
            else -> code
        }
    }
}
