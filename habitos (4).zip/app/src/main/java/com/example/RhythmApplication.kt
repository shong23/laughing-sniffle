package com.example

import android.app.Application
import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class RhythmApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        initFirebase(this)
    }

    companion object {
        fun initFirebase(context: Context) {
            try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    val app = FirebaseApp.initializeApp(context)
                    if (app == null) {
                        val options = FirebaseOptions.Builder()
                            .setApplicationId("1:863046735016:android:6d8f574cda243562071e9d")
                            .setApiKey("AIzaSyDrvMP-NW_WyUkIY7wR2EiyKJ0ILZO33e8")
                            .setProjectId("pulse-ee79e")
                            .setStorageBucket("pulse-ee79e.firebasestorage.app")
                            .setGcmSenderId("863046735016")
                            .build()
                        FirebaseApp.initializeApp(context, options)
                    }
                }
            } catch (e: Exception) {
                Log.w("RhythmApplication", "Default FirebaseApp auto-init failed, initializing fallback options: ${e.message}")
                try {
                    if (FirebaseApp.getApps(context).isEmpty()) {
                        val options = FirebaseOptions.Builder()
                            .setApplicationId("1:863046735016:android:6d8f574cda243562071e9d")
                            .setApiKey("AIzaSyDrvMP-NW_WyUkIY7wR2EiyKJ0ILZO33e8")
                            .setProjectId("pulse-ee79e")
                            .setStorageBucket("pulse-ee79e.firebasestorage.app")
                            .setGcmSenderId("863046735016")
                            .build()
                        FirebaseApp.initializeApp(context, options)
                    }
                } catch (inner: Exception) {
                    Log.w("RhythmApplication", "FirebaseApp fallback initialization note: ${inner.message}")
                }
            }
        }
    }
}
