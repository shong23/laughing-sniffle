package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.DateUtils
import kotlinx.coroutines.launch

private const val PAGER_BASE_PAGE = 10000
private const val PAGER_TOTAL_PAGES = 20000

@Composable
fun DateStrip(
    selectedDate: String,
    onDateSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    val coroutineScope = rememberCoroutineScope()
    val today = remember { DateUtils.getTodayString() }

    val initialWeekOffset = remember { DateUtils.getWeekOffsetForDate(selectedDate) }
    val pagerState = rememberPagerState(
        initialPage = PAGER_BASE_PAGE + initialWeekOffset,
        pageCount = { PAGER_TOTAL_PAGES }
    )

    // Sync pager when selectedDate is updated externally to a different week
    LaunchedEffect(selectedDate) {
        val targetOffset = DateUtils.getWeekOffsetForDate(selectedDate)
        val targetPage = PAGER_BASE_PAGE + targetOffset
        if (pagerState.currentPage != targetPage && !pagerState.isScrollInProgress) {
            pagerState.animateScrollToPage(targetPage)
        }
    }

    val currentWeekOffset = pagerState.currentPage - PAGER_BASE_PAGE
    val visibleWeekDates = remember(pagerState.currentPage) {
        DateUtils.getWeekDatesForOffset(currentWeekOffset, startOnMonday = true)
    }
    val visibleMonthHeader = remember(visibleWeekDates) {
        DateUtils.formatWeekMonthYear(visibleWeekDates)
    }
    val isViewingCurrentWeekAndTodaySelected = currentWeekOffset == 0 && selectedDate == today

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // Month & Navigation Header Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = visibleMonthHeader,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 16.sp,
                    modifier = Modifier.testTag("date_strip_month_header")
                )

                if (currentWeekOffset != 0) {
                    Text(
                        text = if (currentWeekOffset > 0) "+${currentWeekOffset}w" else "${currentWeekOffset}w",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // "Today" button to return to the current day
                AnimatedVisibility(
                    visible = !isViewingCurrentWeekAndTodaySelected,
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut()
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                            .clickable {
                                coroutineScope.launch {
                                    pagerState.animateScrollToPage(PAGER_BASE_PAGE)
                                }
                                onDateSelected(today)
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                            .testTag("button_today"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Today",
                                tint = accentColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Today",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = accentColor
                            )
                        }
                    }
                }

                // Previous Week
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            if (pagerState.currentPage > 0) {
                                pagerState.animateScrollToPage(pagerState.currentPage - 1)
                            }
                        }
                    },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("button_prev_week")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Week",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Next Week
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            if (pagerState.currentPage < PAGER_TOTAL_PAGES - 1) {
                                pagerState.animateScrollToPage(pagerState.currentPage + 1)
                            }
                        }
                    },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("button_next_week")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Next Week",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Horizontal Week Pager with Smooth Snapping
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("horizontal_week_pager"),
            beyondViewportPageCount = 1
        ) { pageIndex ->
            val weekOffset = pageIndex - PAGER_BASE_PAGE
            val weekDates = remember(pageIndex) {
                DateUtils.getWeekDatesForOffset(weekOffset, startOnMonday = true)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val isDark = MaterialTheme.colorScheme.background.red < 0.5f

                weekDates.forEach { dateIso ->
                    val isSelected = dateIso == selectedDate
                    val isToday = dateIso == today
                    val dayOfWeek = DateUtils.getDayOfWeek(dateIso)
                    val dayShort = DateUtils.getDayOfWeekShort(dayOfWeek).take(1)
                    val dayNumber = dateIso.substringAfterLast("-").toIntOrNull() ?: 1

                    val bgColor by animateColorAsState(
                        targetValue = when {
                            isSelected -> accentColor
                            else -> if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                    else MaterialTheme.colorScheme.surface
                        },
                        label = "DateBgColor"
                    )

                    val textColor by animateColorAsState(
                        targetValue = when {
                            isSelected -> if (isDark) Color.Black else Color.White
                            isToday -> if (isDark) accentColor else MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        label = "DateTextColor"
                    )

                    val chipBorderColor = when {
                        isSelected -> Color.Transparent
                        isToday -> (if (isDark) accentColor else MaterialTheme.colorScheme.primary).copy(alpha = 0.4f)
                        else -> if (isDark) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 3.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(bgColor)
                            .border(1.dp, chipBorderColor, RoundedCornerShape(16.dp))
                            .clickable { onDateSelected(dateIso) }
                            .padding(vertical = 10.dp)
                            .testTag("date_chip_$dateIso"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = dayShort,
                                style = MaterialTheme.typography.labelSmall,
                                color = textColor.copy(alpha = if (isSelected) 0.95f else 0.75f),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = dayNumber.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                color = textColor,
                                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.SemiBold,
                                fontSize = 15.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Highlight indicator dot for today
                            if (isToday && !isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(4.dp)
                                        .clip(CircleShape)
                                        .background(if (isDark) accentColor else MaterialTheme.colorScheme.primary)
                                )
                            } else {
                                Spacer(modifier = Modifier.size(4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
