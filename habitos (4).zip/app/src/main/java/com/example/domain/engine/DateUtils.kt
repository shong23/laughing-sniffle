package com.example.domain.engine

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("EEEE, MMMM d", Locale.US)
    private val monthDayFormat = SimpleDateFormat("MMM d", Locale.US)
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
    private val yearMonthFormat = SimpleDateFormat("yyyy-MM", Locale.US)

    fun getTodayString(): String {
        return isoFormat.format(Date())
    }

    fun isFutureDate(isoDate: String): Boolean {
        return isoDate > getTodayString()
    }

    fun formatDateToIso(calendar: Calendar): String {
        return isoFormat.format(calendar.time)
    }

    fun parseIsoToCalendar(isoDate: String): Calendar {
        val cal = Calendar.getInstance()
        try {
            val date = isoFormat.parse(isoDate)
            if (date != null) cal.time = date
        } catch (_: Exception) {}
        return cal
    }

    fun formatDisplayDate(isoDate: String): String {
        val today = getTodayString()
        if (isoDate == today) return "Today, " + SimpleDateFormat("MMMM d", Locale.US).format(Date())
        val cal = parseIsoToCalendar(isoDate)
        return displayFormat.format(cal.time)
    }

    fun formatMonthDay(isoDate: String): String {
        val cal = parseIsoToCalendar(isoDate)
        return monthDayFormat.format(cal.time)
    }

    fun getYearMonth(isoDate: String = getTodayString()): String {
        val cal = parseIsoToCalendar(isoDate)
        return yearMonthFormat.format(cal.time)
    }

    fun getDayOfWeek(isoDate: String): Int {
        // Returns 1 = Mon, 2 = Tue, ..., 7 = Sun
        val cal = parseIsoToCalendar(isoDate)
        val day = cal.get(Calendar.DAY_OF_WEEK)
        return when (day) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
    }

    fun getDayOfWeekCode(isoDate: String): String {
        return when (getDayOfWeek(isoDate)) {
            1 -> "MON"
            2 -> "TUE"
            3 -> "WED"
            4 -> "THU"
            5 -> "FRI"
            6 -> "SAT"
            7 -> "SUN"
            else -> "MON"
        }
    }

    fun getDayOfWeekShort(dayOfWeek: Int): String {
        return when (dayOfWeek) {
            1 -> "Mon"
            2 -> "Tue"
            3 -> "Wed"
            4 -> "Thu"
            5 -> "Fri"
            6 -> "Sat"
            7 -> "Sun"
            else -> "Mon"
        }
    }

    fun getGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..21 -> "Good evening"
            else -> "Good night"
        }
    }

    fun getDaysInRange(startDateIso: String, endDateIso: String): List<String> {
        val list = mutableListOf<String>()
        val startCal = parseIsoToCalendar(startDateIso)
        val endCal = parseIsoToCalendar(endDateIso)

        while (!startCal.after(endCal)) {
            list.add(isoFormat.format(startCal.time))
            startCal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return list
    }

    fun getPastDays(count: Int, includeToday: Boolean = true): List<String> {
        val list = mutableListOf<String>()
        val cal = Calendar.getInstance()
        if (!includeToday) {
            cal.add(Calendar.DAY_OF_MONTH, -1)
        }
        for (i in 0 until count) {
            list.add(isoFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_MONTH, -1)
        }
        return list.reversed()
    }

    fun isToday(isoDate: String): Boolean {
        return isoDate == getTodayString()
    }

    fun getWeekStartCalendar(anchorIso: String = getTodayString(), startOnMonday: Boolean = true): Calendar {
        val cal = parseIsoToCalendar(anchorIso)
        cal.firstDayOfWeek = if (startOnMonday) Calendar.MONDAY else Calendar.SUNDAY
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val diff = if (startOnMonday) {
            if (dayOfWeek == Calendar.SUNDAY) -6 else Calendar.MONDAY - dayOfWeek
        } else {
            Calendar.SUNDAY - dayOfWeek
        }
        cal.add(Calendar.DAY_OF_MONTH, diff)
        return cal
    }

    fun getWeekDatesForOffset(weekOffset: Int, startOnMonday: Boolean = true): List<String> {
        val cal = getWeekStartCalendar(getTodayString(), startOnMonday)
        cal.add(Calendar.DAY_OF_MONTH, weekOffset * 7)
        val week = mutableListOf<String>()
        for (i in 0..6) {
            week.add(isoFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return week
    }

    fun getWeekOffsetForDate(isoDate: String, startOnMonday: Boolean = true): Int {
        val todayWeekStart = getWeekStartCalendar(getTodayString(), startOnMonday)
        val targetWeekStart = getWeekStartCalendar(isoDate, startOnMonday)
        val diffMillis = targetWeekStart.timeInMillis - todayWeekStart.timeInMillis
        val days = (diffMillis / (1000 * 60 * 60 * 24)).toDouble()
        return Math.round(days / 7.0).toInt()
    }

    fun formatWeekMonthYear(weekDates: List<String>): String {
        if (weekDates.isEmpty()) return ""
        val firstCal = parseIsoToCalendar(weekDates.first())
        val lastCal = parseIsoToCalendar(weekDates.last())
        
        val firstMonth = SimpleDateFormat("MMM", Locale.US).format(firstCal.time)
        val lastMonth = SimpleDateFormat("MMM", Locale.US).format(lastCal.time)
        val firstYear = firstCal.get(Calendar.YEAR)
        val lastYear = lastCal.get(Calendar.YEAR)

        return when {
            firstYear != lastYear -> "$firstMonth $firstYear – $lastMonth $lastYear"
            firstMonth != lastMonth -> "$firstMonth – $lastMonth $firstYear"
            else -> SimpleDateFormat("MMMM yyyy", Locale.US).format(firstCal.time)
        }
    }

    fun getWeekDates(anchorDateIso: String, startOnMonday: Boolean = true): List<String> {
        val cal = parseIsoToCalendar(anchorDateIso)
        cal.firstDayOfWeek = if (startOnMonday) Calendar.MONDAY else Calendar.SUNDAY
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        
        val diff = if (startOnMonday) {
            if (dayOfWeek == Calendar.SUNDAY) -6 else Calendar.MONDAY - dayOfWeek
        } else {
            Calendar.SUNDAY - dayOfWeek
        }
        
        cal.add(Calendar.DAY_OF_MONTH, diff)
        val week = mutableListOf<String>()
        for (i in 0..6) {
            week.add(isoFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return week
    }

    fun addDays(isoDate: String, days: Int): String {
        val cal = parseIsoToCalendar(isoDate)
        cal.add(Calendar.DAY_OF_MONTH, days)
        return isoFormat.format(cal.time)
    }
}
