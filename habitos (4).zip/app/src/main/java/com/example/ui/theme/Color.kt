package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Canvas Tokens
val DarkBackground = Color(0xFF08090C)
val DarkSurface = Color(0xFF12141A)
val DarkSurfaceElevated = Color(0xFF1B1E27)
val DarkSurfaceHighlight = Color(0xFF252A37)
val DarkBorder = Color(0xFF222734)

val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Soft, soothing, eye-comfortable light mode palette (reduces glare & eye fatigue)
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEFF2F7)
val LightSurfaceHighlight = Color(0xFFE4E9F2)
val LightBorder = Color(0xFFE2E6EE)

val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF64748B)

// Vibrant Category Accents (Kept exact same brand colors)
val AccentHealth = Color(0xFFB6FF00) // Electric Lime
val AccentMind = Color(0xFFA855F7)   // Deep Lavender
val AccentFocus = Color(0xFF00E5FF)  // Electric Cyan
val AccentFinance = Color(0xFFFFD60A)// Warm Gold
val AccentSocial = Color(0xFFFF4D8D) // Rose Punch
val AccentEnergy = Color(0xFFFF7A00) // Solar Orange
val AccentGrace = Color(0xFF8B5CF6)  // Royal Shield Violet

fun parseColorHex(hex: String, defaultColor: Color = AccentHealth): Color {
    return try {
        val cleanHex = hex.removePrefix("#")
        val colorInt = cleanHex.toLong(16)
        if (cleanHex.length == 6) {
            Color(0xFF000000 or colorInt)
        } else {
            Color(colorInt)
        }
    } catch (_: Exception) {
        defaultColor
    }
}

/**
 * Returns an eye-comfortable text/icon color for an accent.
 * In Dark Mode: Uses the vibrant glowing accent directly.
 * In Light Mode: Uses a deeply saturated, high-contrast companion shade for crisp reading without eye strain.
 */
fun getComfortableAccentTextColor(accentColor: Color, isDark: Boolean): Color {
    if (isDark) return accentColor
    return when (accentColor) {
        AccentHealth -> Color(0xFF2D6A00) // Deep Forest Lime
        AccentFocus -> Color(0xFF02687A)  // Deep Ocean Teal
        AccentFinance -> Color(0xFF9A6700)// Deep Warm Amber
        AccentSocial -> Color(0xFFBE123C) // Deep Crimson Rose
        AccentEnergy -> Color(0xFFC2410C) // Deep Sunset Orange
        AccentMind -> Color(0xFF6D28D9)   // Deep Royal Violet
        AccentGrace -> Color(0xFF5B21B6)  // Deep Shield Violet
        else -> {
            // General luminance check
            val luminance = 0.299f * accentColor.red + 0.587f * accentColor.green + 0.114f * accentColor.blue
            if (luminance > 0.55f) {
                Color(
                    red = (accentColor.red * 0.45f).coerceIn(0f, 1f),
                    green = (accentColor.green * 0.45f).coerceIn(0f, 1f),
                    blue = (accentColor.blue * 0.45f).coerceIn(0f, 1f),
                    alpha = 1.0f
                )
            } else accentColor
        }
    }
}

/**
 * Gradient background brush for habit cards in both light and dark modes
 */
fun getCardBackgroundBrush(
    isDark: Boolean,
    isCompleted: Boolean,
    isGrace: Boolean,
    accentColor: Color
): Brush {
    return if (isDark) {
        when {
            isCompleted -> Brush.verticalGradient(
                listOf(DarkSurfaceElevated, DarkSurface)
            )
            isGrace -> Brush.verticalGradient(
                listOf(AccentGrace.copy(alpha = 0.12f), DarkSurface)
            )
            else -> Brush.verticalGradient(
                listOf(DarkSurface, DarkSurfaceElevated.copy(alpha = 0.5f))
            )
        }
    } else {
        when {
            isCompleted -> Brush.verticalGradient(
                listOf(
                    Color(0xFFFFFFFF),
                    accentColor.copy(alpha = 0.08f)
                )
            )
            isGrace -> Brush.verticalGradient(
                listOf(
                    Color(0xFFFFFFFF),
                    AccentGrace.copy(alpha = 0.08f)
                )
            )
            else -> Brush.verticalGradient(
                listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF9FAFC)
                )
            )
        }
    }
}
