package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.HabitRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val habitRepository: HabitRepository,
    val authRepository: AuthRepository
) : ViewModel() {

    val currentUser: StateFlow<UserEntity?> = authRepository.currentUser

    private val _isTourOpen = MutableStateFlow(false)
    val isTourOpen: StateFlow<Boolean> = _isTourOpen.asStateFlow()

    private val _isEditProfileOpen = MutableStateFlow(false)
    val isEditProfileOpen: StateFlow<Boolean> = _isEditProfileOpen.asStateFlow()

    val settings: StateFlow<UserSettingsEntity?> = settingsRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun setThemeMode(themeMode: String) {
        viewModelScope.launch {
            settingsRepository.updateThemeMode(themeMode)
        }
    }

    fun setGraceDaysLimit(limit: Int) {
        viewModelScope.launch {
            settingsRepository.updateGraceDaysLimit(limit)
        }
    }

    fun setHaptics(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateHaptics(enabled)
        }
    }

    fun setSound(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateSound(enabled)
        }
    }

    fun setReminderNotifications(enabled: Boolean, context: android.content.Context? = null) {
        viewModelScope.launch {
            settingsRepository.updateReminderNotifications(enabled)
            context?.let { ctx ->
                com.example.notification.NotificationScheduler.syncReminders(ctx, enabled)
            }
        }
    }

    fun setWeekStart(startMonday: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateWeekStart(startMonday)
        }
    }

    fun openTour() {
        _isTourOpen.value = true
    }

    fun closeTour() {
        _isTourOpen.value = false
    }

    fun completeTour() {
        viewModelScope.launch {
            authRepository.setTourCompleted(true)
            _isTourOpen.value = false
        }
    }

    fun openEditProfile() {
        _isEditProfileOpen.value = true
    }

    fun closeEditProfile() {
        _isEditProfileOpen.value = false
    }

    fun updateProfile(displayName: String, avatarColorHex: String) {
        viewModelScope.launch {
            authRepository.updateProfile(displayName, avatarColorHex)
            _isEditProfileOpen.value = false
        }
    }

    fun clearAllUserData() {
        viewModelScope.launch {
            habitRepository.clearAllUserData()
        }
    }

    fun loadStarterHabits() {
        viewModelScope.launch {
            habitRepository.seedStarterHabitsForUser()
        }
    }

    fun signOut(onSignedOut: () -> Unit) {
        authRepository.signOut()
        onSignedOut()
    }
}

class SettingsViewModelFactory(
    private val settingsRepository: SettingsRepository,
    private val habitRepository: HabitRepository,
    private val authRepository: AuthRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SettingsViewModel(settingsRepository, habitRepository, authRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
