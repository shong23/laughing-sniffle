package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.AppDatabase
import com.example.data.sync.SyncRepository
import com.example.data.repository.AuthRepository
import com.example.data.repository.HabitRepository
import com.example.data.repository.SettingsRepository
import com.example.notification.NotificationScheduler
import com.example.ui.screens.analytics.AnalyticsScreen
import com.example.ui.screens.analytics.AnalyticsViewModel
import com.example.ui.screens.analytics.AnalyticsViewModelFactory
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.settings.SettingsViewModelFactory
import com.example.ui.screens.today.TodayScreen
import com.example.ui.screens.today.TodayViewModel
import com.example.ui.screens.today.TodayViewModelFactory
import com.example.ui.screens.tour.AppTourDialog
import com.example.ui.theme.RhythmTheme
import com.example.util.FeedbackManager
import kotlinx.coroutines.launch

const val ROUTE_TODAY = "today"
const val ROUTE_ANALYTICS = "analytics"
const val ROUTE_SETTINGS = "settings"

class MainActivity : ComponentActivity() {

    private var feedbackManager: FeedbackManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val authRepository = AuthRepository(
            userDao = database.userDao(),
            context = applicationContext
        )
        val syncRepository = SyncRepository(
            habitDao = database.habitDao(),
            habitLogDao = database.habitLogDao(),
            userStreakDao = database.userStreakDao(),
            userSettingsDao = database.userSettingsDao()
        )
        val habitRepository = HabitRepository(
            habitDao = database.habitDao(),
            habitLogDao = database.habitLogDao(),
            userStreakDao = database.userStreakDao(),
            userSettingsDao = database.userSettingsDao(),
            authRepository = authRepository,
            syncRepository = syncRepository
        )
        val settingsRepository = SettingsRepository(
            userSettingsDao = database.userSettingsDao(),
            authRepository = authRepository,
            syncRepository = syncRepository
        )
        val feedbackMgr = FeedbackManager(applicationContext, database.userSettingsDao())
        this.feedbackManager = feedbackMgr

        // Initialize notification channel and schedule alarms if enabled
        NotificationScheduler.syncReminders(applicationContext, true)

        setContent {
            val userSettings by settingsRepository.settingsFlow.collectAsStateWithLifecycle(initialValue = null)
            val currentUser by authRepository.currentUser.collectAsStateWithLifecycle()
            val themeMode = userSettings?.themeMode ?: "SYSTEM"
            val coroutineScope = rememberCoroutineScope()

            RhythmTheme(themeMode = themeMode) {
                if (currentUser == null) {
                    AuthScreen(
                        authRepository = authRepository,
                        onAuthSuccess = {}
                    )
                } else {
                    RhythmMainApp(
                        habitRepository = habitRepository,
                        settingsRepository = settingsRepository,
                        authRepository = authRepository,
                        feedbackManager = feedbackMgr
                    )

                    // First-time interactive tour guide walkthrough
                    if (!currentUser!!.hasCompletedTour) {
                        AppTourDialog(
                            onDismiss = {
                                coroutineScope.launch {
                                    authRepository.setTourCompleted(true)
                                }
                            },
                            onComplete = {
                                coroutineScope.launch {
                                    authRepository.setTourCompleted(true)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        feedbackManager?.release()
    }
}

sealed class NavItem(val route: String, val title: String, val icon: ImageVector, val tag: String) {
    object Today : NavItem(ROUTE_TODAY, "Today", Icons.Default.CalendarToday, "nav_today")
    object Analytics : NavItem(ROUTE_ANALYTICS, "Analytics", Icons.AutoMirrored.Filled.TrendingUp, "nav_analytics")
    object Settings : NavItem(ROUTE_SETTINGS, "Settings", Icons.Default.Settings, "nav_settings")
}

@Composable
fun RhythmMainApp(
    habitRepository: HabitRepository,
    settingsRepository: SettingsRepository,
    authRepository: AuthRepository,
    feedbackManager: FeedbackManager? = null
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_TODAY

    val navItems = listOf(NavItem.Today, NavItem.Analytics, NavItem.Settings)

    val todayViewModel: TodayViewModel = viewModel(
        factory = TodayViewModelFactory(habitRepository, feedbackManager)
    )
    val analyticsViewModel: AnalyticsViewModel = viewModel(
        factory = AnalyticsViewModelFactory(habitRepository)
    )
    val settingsViewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModelFactory(settingsRepository, habitRepository, authRepository)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp
            ) {
                navItems.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(ROUTE_TODAY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(item.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ROUTE_TODAY,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(ROUTE_TODAY) {
                TodayScreen(viewModel = todayViewModel)
            }
            composable(ROUTE_ANALYTICS) {
                AnalyticsScreen(viewModel = analyticsViewModel)
            }
            composable(ROUTE_SETTINGS) {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    onSignOut = {
                        navController.popBackStack(ROUTE_TODAY, false)
                    }
                )
            }
        }
    }
}
