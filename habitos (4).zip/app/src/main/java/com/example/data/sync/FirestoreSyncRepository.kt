package com.example.data.sync

import android.util.Log
import com.example.data.local.dao.HabitDao
import com.example.data.local.dao.HabitLogDao
import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.dao.UserStreakDao
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.UserStreakEntity
import com.example.domain.engine.SmartStreakEngine
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * FirestoreSyncRepository
 *
 * Provides real-time, bi-directional synchronization between local Room SQLite database
 * and Google Cloud Firestore.
 *
 * Remote Path Architecture:
 * - /users/{userId}/habits/{habitId}
 * - /users/{userId}/logs/{habitId_date}
 * - /users/{userId}/streaks/{habitId}
 * - /users/{userId}/settings/user_settings
 */
class FirestoreSyncRepository(
    private val habitDao: HabitDao,
    private val habitLogDao: HabitLogDao,
    private val userStreakDao: UserStreakDao,
    private val userSettingsDao: UserSettingsDao,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val firestore: FirebaseFirestore?
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.d(TAG, "Firestore initialization note: ${e.message}")
            null
        }

    private var habitListenerRegistration: ListenerRegistration? = null
    private var logListenerRegistration: ListenerRegistration? = null
    private var streakListenerRegistration: ListenerRegistration? = null
    private var settingsListenerRegistration: ListenerRegistration? = null
    private var activeSyncUserId: String? = null

    /**
     * Start bi-directional real-time sync for an authenticated user.
     * Pulls remote data, pushes local unsynced data, and listens for live remote updates.
     */
    fun startSyncForUser(userId: String) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        if (activeSyncUserId == userId) return

        stopSync()
        activeSyncUserId = userId

        scope.launch {
            // 1. Pull existing history from Firestore to Room
            pullAllFromCloud(userId)

            // 2. Push any local records up to Firestore
            pushLocalDataToCloud(userId)

            // 3. Attach real-time snapshot listeners for live multi-device syncing
            attachRealtimeListeners(userId)
        }
    }

    /**
     * Pulls all habits, logs, streaks, and user settings from Cloud Firestore into Room.
     */
    suspend fun pullAllFromCloud(userId: String) = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext
        try {
            Log.d(TAG, "Pulling remote Firestore collections for user: $userId")

            // 1. Pull Habits (/users/{userId}/habits/{habitId})
            val habitsSnapshot = db.collection("users")
                .document(userId)
                .collection("habits")
                .get()
                .await()

            for (doc in habitsSnapshot.documents) {
                val data = doc.data ?: continue
                try {
                    val habit = HabitEntity(
                        id = (data["id"] as? Number)?.toLong() ?: doc.id.toLongOrNull() ?: System.currentTimeMillis(),
                        userId = userId,
                        name = data["name"] as? String ?: "Habit",
                        description = data["description"] as? String ?: "",
                        category = data["category"] as? String ?: "Health",
                        iconName = data["iconName"] as? String ?: "water_drop",
                        colorHex = data["colorHex"] as? String ?: "#B6FF00",
                        frequencyType = data["frequencyType"] as? String ?: "DAILY",
                        frequencyConfig = data["frequencyConfig"] as? String ?: "MON,TUE,WED,THU,FRI,SAT,SUN",
                        targetCount = (data["targetCount"] as? Number)?.toInt() ?: 1,
                        unit = data["unit"] as? String ?: "times",
                        timeOfDay = data["timeOfDay"] as? String ?: "ANYTIME",
                        reminderTime = data["reminderTime"] as? String,
                        startDate = data["startDate"] as? String ?: "",
                        archived = data["archived"] as? Boolean ?: false,
                        createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                        updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                    )
                    habitDao.insertHabit(habit)
                } catch (e: Exception) {
                    Log.w(TAG, "Error mapping habit ${doc.id}: ${e.message}")
                }
            }

            // 2. Pull Logs (/users/{userId}/logs/{habitId_date})
            val logsSnapshot = db.collection("users")
                .document(userId)
                .collection("logs")
                .get()
                .await()

            for (doc in logsSnapshot.documents) {
                val data = doc.data ?: continue
                try {
                    val habitId = (data["habitId"] as? Number)?.toLong()
                        ?: doc.id.substringBefore("_").toLongOrNull()
                        ?: continue
                    val date = data["date"] as? String
                        ?: doc.id.substringAfter("_")

                    val log = HabitLogEntity(
                        id = (data["id"] as? Number)?.toLong() ?: 0L,
                        habitId = habitId,
                        date = date,
                        status = data["status"] as? String ?: "COMPLETED",
                        value = (data["value"] as? Number)?.toInt() ?: 1,
                        completedAt = (data["completedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                        notes = data["notes"] as? String
                    )
                    habitLogDao.insertLog(log)
                } catch (e: Exception) {
                    Log.w(TAG, "Error mapping log ${doc.id}: ${e.message}")
                }
            }

            // 3. Pull Streaks (/users/{userId}/streaks/{habitId})
            val streaksSnapshot = db.collection("users")
                .document(userId)
                .collection("streaks")
                .get()
                .await()

            for (doc in streaksSnapshot.documents) {
                val data = doc.data ?: continue
                try {
                    val habitId = (data["habitId"] as? Number)?.toLong() ?: doc.id.toLongOrNull() ?: continue
                    val streak = UserStreakEntity(
                        habitId = habitId,
                        currentStreak = (data["currentStreak"] as? Number)?.toInt() ?: 0,
                        longestStreak = (data["longestStreak"] as? Number)?.toInt() ?: 0,
                        totalCompletions = (data["totalCompletions"] as? Number)?.toInt() ?: 0,
                        graceDaysUsedMonth = (data["graceDaysUsedMonth"] as? Number)?.toInt() ?: 0,
                        lastCompletedDate = data["lastCompletedDate"] as? String,
                        completionRate = (data["completionRate"] as? Number)?.toFloat() ?: 0f,
                        updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                    )
                    userStreakDao.upsertStreak(streak)
                } catch (e: Exception) {
                    Log.w(TAG, "Error mapping streak ${doc.id}: ${e.message}")
                }
            }

            // 4. Pull Settings (/users/{userId}/settings/user_settings)
            val settingsDoc = db.collection("users")
                .document(userId)
                .collection("settings")
                .document("user_settings")
                .get()
                .await()

            if (settingsDoc.exists()) {
                val data = settingsDoc.data
                if (data != null) {
                    val settings = UserSettingsEntity(
                        id = 1,
                        userId = userId,
                        themeMode = data["themeMode"] as? String ?: "SYSTEM",
                        accentColor = data["accentColor"] as? String ?: "#B6FF00",
                        graceDaysPerMonth = (data["graceDaysPerMonth"] as? Number)?.toInt() ?: 2,
                        hapticsEnabled = data["hapticsEnabled"] as? Boolean ?: true,
                        soundEnabled = data["soundEnabled"] as? Boolean ?: true,
                        weekStartMonday = data["weekStartMonday"] as? Boolean ?: true,
                        onboardingCompleted = data["onboardingCompleted"] as? Boolean ?: false,
                        reminderNotifications = data["reminderNotifications"] as? Boolean ?: true
                    )
                    userSettingsDao.saveSettings(settings)
                }
            }

            // 5. Recalculate streaks for all local habits to ensure accurate stats
            val localHabits = habitDao.getActiveHabitsList(userId)
            for (habit in localHabits) {
                val logs = habitLogDao.getLogsListForHabit(habit.id)
                val streak = SmartStreakEngine.calculateStreak(habit, logs)
                userStreakDao.upsertStreak(streak)
            }

            Log.d(TAG, "Successfully pulled remote Firestore data into Room")
        } catch (e: Exception) {
            Log.d(TAG, "Firestore pull completed with offline cache: ${e.message}")
        }
    }

    /**
     * Push any existing local data for this user to Firestore
     */
    private suspend fun pushLocalDataToCloud(userId: String) = withContext(Dispatchers.IO) {
        try {
            val localHabits = habitDao.getActiveHabitsList(userId)
            for (habit in localHabits) {
                syncHabitUp(habit)
            }
            val localLogs = habitLogDao.getAllLogsList()
            for (log in localLogs) {
                syncLogUp(userId, log)
            }
            val localStreaks = userStreakDao.getAllStreaks()
            for (streak in localStreaks) {
                syncStreakUp(userId, streak)
            }
            val localSettings = userSettingsDao.getSettings()
            if (localSettings != null) {
                syncSettingsUp(userId, localSettings)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Push local data note: ${e.message}")
        }
    }

    /**
     * Attaches real-time snapshot listeners to keep local Room database in sync with remote changes.
     */
    private fun attachRealtimeListeners(userId: String) {
        val db = firestore ?: return
        try {
            // Listen to Habits
            habitListenerRegistration = db.collection("users")
                .document(userId)
                .collection("habits")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    scope.launch {
                        for (change in snapshots.documentChanges) {
                            val doc = change.document
                            val data = doc.data
                            try {
                                val habit = HabitEntity(
                                    id = (data["id"] as? Number)?.toLong() ?: doc.id.toLongOrNull() ?: 0L,
                                    userId = userId,
                                    name = data["name"] as? String ?: "Habit",
                                    description = data["description"] as? String ?: "",
                                    category = data["category"] as? String ?: "Health",
                                    iconName = data["iconName"] as? String ?: "water_drop",
                                    colorHex = data["colorHex"] as? String ?: "#B6FF00",
                                    frequencyType = data["frequencyType"] as? String ?: "DAILY",
                                    frequencyConfig = data["frequencyConfig"] as? String ?: "MON,TUE,WED,THU,FRI,SAT,SUN",
                                    targetCount = (data["targetCount"] as? Number)?.toInt() ?: 1,
                                    unit = data["unit"] as? String ?: "times",
                                    timeOfDay = data["timeOfDay"] as? String ?: "ANYTIME",
                                    reminderTime = data["reminderTime"] as? String,
                                    startDate = data["startDate"] as? String ?: "",
                                    archived = data["archived"] as? Boolean ?: false,
                                    createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                    updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                                )
                                if (change.type == DocumentChange.Type.REMOVED) {
                                    habitDao.deleteHabit(habit.id)
                                } else {
                                    habitDao.insertHabit(habit)
                                }
                            } catch (e: Exception) {
                                Log.d(TAG, "Habit snapshot change note: ${e.message}")
                            }
                        }
                    }
                }

            // Listen to Logs
            logListenerRegistration = db.collection("users")
                .document(userId)
                .collection("logs")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    scope.launch {
                        for (change in snapshots.documentChanges) {
                            val doc = change.document
                            val data = doc.data
                            try {
                                val habitId = (data["habitId"] as? Number)?.toLong()
                                    ?: doc.id.substringBefore("_").toLongOrNull()
                                    ?: continue
                                val date = data["date"] as? String
                                    ?: doc.id.substringAfter("_")

                                val log = HabitLogEntity(
                                    id = (data["id"] as? Number)?.toLong() ?: 0L,
                                    habitId = habitId,
                                    date = date,
                                    status = data["status"] as? String ?: "COMPLETED",
                                    value = (data["value"] as? Number)?.toInt() ?: 1,
                                    completedAt = (data["completedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                    notes = data["notes"] as? String
                                )
                                if (change.type == DocumentChange.Type.REMOVED) {
                                    habitLogDao.deleteLog(log.habitId, log.date)
                                } else {
                                    habitLogDao.insertLog(log)
                                }
                            } catch (e: Exception) {
                                Log.d(TAG, "Log snapshot change note: ${e.message}")
                            }
                        }
                    }
                }

            // Listen to Streaks
            streakListenerRegistration = db.collection("users")
                .document(userId)
                .collection("streaks")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    scope.launch {
                        for (change in snapshots.documentChanges) {
                            val doc = change.document
                            val data = doc.data
                            try {
                                val habitId = (data["habitId"] as? Number)?.toLong() ?: doc.id.toLongOrNull() ?: continue
                                val streak = UserStreakEntity(
                                    habitId = habitId,
                                    currentStreak = (data["currentStreak"] as? Number)?.toInt() ?: 0,
                                    longestStreak = (data["longestStreak"] as? Number)?.toInt() ?: 0,
                                    totalCompletions = (data["totalCompletions"] as? Number)?.toInt() ?: 0,
                                    graceDaysUsedMonth = (data["graceDaysUsedMonth"] as? Number)?.toInt() ?: 0,
                                    lastCompletedDate = data["lastCompletedDate"] as? String,
                                    completionRate = (data["completionRate"] as? Number)?.toFloat() ?: 0f,
                                    updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                                )
                                if (change.type == DocumentChange.Type.REMOVED) {
                                    userStreakDao.deleteStreak(habitId)
                                } else {
                                    userStreakDao.upsertStreak(streak)
                                }
                            } catch (e: Exception) {
                                Log.d(TAG, "Streak snapshot change note: ${e.message}")
                            }
                        }
                    }
                }

            // Listen to User Settings
            settingsListenerRegistration = db.collection("users")
                .document(userId)
                .collection("settings")
                .document("user_settings")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    scope.launch {
                        val data = snapshot.data ?: return@launch
                        try {
                            val settings = UserSettingsEntity(
                                id = 1,
                                userId = userId,
                                themeMode = data["themeMode"] as? String ?: "SYSTEM",
                                accentColor = data["accentColor"] as? String ?: "#B6FF00",
                                graceDaysPerMonth = (data["graceDaysPerMonth"] as? Number)?.toInt() ?: 2,
                                hapticsEnabled = data["hapticsEnabled"] as? Boolean ?: true,
                                soundEnabled = data["soundEnabled"] as? Boolean ?: true,
                                weekStartMonday = data["weekStartMonday"] as? Boolean ?: true,
                                onboardingCompleted = data["onboardingCompleted"] as? Boolean ?: false,
                                reminderNotifications = data["reminderNotifications"] as? Boolean ?: true
                            )
                            userSettingsDao.saveSettings(settings)
                        } catch (e: Exception) {
                            Log.d(TAG, "Settings snapshot change note: ${e.message}")
                        }
                    }
                }
        } catch (e: Exception) {
            Log.d(TAG, "Realtime listeners attachment note: ${e.message}")
        }
    }

    /**
     * Push a habit to /users/{userId}/habits/{habitId}
     */
    fun syncHabitUp(habit: HabitEntity) {
        val userId = habit.userId
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                val map = hashMapOf<String, Any?>(
                    "id" to habit.id,
                    "userId" to habit.userId,
                    "name" to habit.name,
                    "description" to habit.description,
                    "category" to habit.category,
                    "iconName" to habit.iconName,
                    "colorHex" to habit.colorHex,
                    "frequencyType" to habit.frequencyType,
                    "frequencyConfig" to habit.frequencyConfig,
                    "targetCount" to habit.targetCount,
                    "unit" to habit.unit,
                    "timeOfDay" to habit.timeOfDay,
                    "reminderTime" to habit.reminderTime,
                    "startDate" to habit.startDate,
                    "archived" to habit.archived,
                    "createdAt" to habit.createdAt,
                    "updatedAt" to habit.updatedAt
                )
                db.collection("users")
                    .document(userId)
                    .collection("habits")
                    .document(habit.id.toString())
                    .set(map, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "syncHabitUp note: ${e.message}")
            }
        }
    }

    /**
     * Delete a habit from /users/{userId}/habits/{habitId}
     */
    fun deleteHabitRemote(userId: String, habitId: Long) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                db.collection("users")
                    .document(userId)
                    .collection("habits")
                    .document(habitId.toString())
                    .delete()
                    .await()

                db.collection("users")
                    .document(userId)
                    .collection("streaks")
                    .document(habitId.toString())
                    .delete()
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "deleteHabitRemote note: ${e.message}")
            }
        }
    }

    /**
     * Push a completion log to /users/{userId}/logs/{habitId_date}
     */
    fun syncLogUp(userId: String, log: HabitLogEntity) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                val docId = "${log.habitId}_${log.date}"
                val map = hashMapOf<String, Any?>(
                    "id" to log.id,
                    "habitId" to log.habitId,
                    "date" to log.date,
                    "status" to log.status,
                    "value" to log.value,
                    "completedAt" to log.completedAt,
                    "notes" to log.notes
                )
                db.collection("users")
                    .document(userId)
                    .collection("logs")
                    .document(docId)
                    .set(map, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "syncLogUp note: ${e.message}")
            }
        }
    }

    /**
     * Delete a completion log from /users/{userId}/logs/{habitId_date}
     */
    fun deleteLogRemote(userId: String, habitId: Long, date: String) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                val docId = "${habitId}_${date}"
                db.collection("users")
                    .document(userId)
                    .collection("logs")
                    .document(docId)
                    .delete()
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "deleteLogRemote note: ${e.message}")
            }
        }
    }

    /**
     * Push streak statistics to /users/{userId}/streaks/{habitId}
     */
    fun syncStreakUp(userId: String, streak: UserStreakEntity) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                val map = hashMapOf<String, Any?>(
                    "habitId" to streak.habitId,
                    "currentStreak" to streak.currentStreak,
                    "longestStreak" to streak.longestStreak,
                    "totalCompletions" to streak.totalCompletions,
                    "graceDaysUsedMonth" to streak.graceDaysUsedMonth,
                    "lastCompletedDate" to streak.lastCompletedDate,
                    "completionRate" to streak.completionRate,
                    "updatedAt" to streak.updatedAt
                )
                db.collection("users")
                    .document(userId)
                    .collection("streaks")
                    .document(streak.habitId.toString())
                    .set(map, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "syncStreakUp note: ${e.message}")
            }
        }
    }

    /**
     * Push user settings to /users/{userId}/settings/user_settings
     */
    fun syncSettingsUp(userId: String, settings: UserSettingsEntity) {
        if (userId.isBlank() || userId == "guest_user" || userId == "guest") return
        val db = firestore ?: return
        scope.launch {
            try {
                val map = hashMapOf<String, Any?>(
                    "userId" to userId,
                    "themeMode" to settings.themeMode,
                    "accentColor" to settings.accentColor,
                    "graceDaysPerMonth" to settings.graceDaysPerMonth,
                    "hapticsEnabled" to settings.hapticsEnabled,
                    "soundEnabled" to settings.soundEnabled,
                    "weekStartMonday" to settings.weekStartMonday,
                    "onboardingCompleted" to settings.onboardingCompleted,
                    "reminderNotifications" to settings.reminderNotifications
                )
                db.collection("users")
                    .document(userId)
                    .collection("settings")
                    .document("user_settings")
                    .set(map, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.d(TAG, "syncSettingsUp note: ${e.message}")
            }
        }
    }

    fun stopSync() {
        habitListenerRegistration?.remove()
        habitListenerRegistration = null
        logListenerRegistration?.remove()
        logListenerRegistration = null
        streakListenerRegistration?.remove()
        streakListenerRegistration = null
        settingsListenerRegistration?.remove()
        settingsListenerRegistration = null
        activeSyncUserId = null
    }

    companion object {
        private const val TAG = "FirestoreSyncRepository"
    }
}
