package com.example.domain.engine

import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.domain.model.InsightItem
import com.example.domain.model.WeekdayStat

object InsightsEngine {

    fun generateInsights(
        habits: List<HabitEntity>,
        logs: List<HabitLogEntity>,
        weekdayStats: List<WeekdayStat>,
        overallConsistency: Int,
        graceDaysUsed: Int,
        graceDaysLimit: Int
    ): List<InsightItem> {
        val insights = mutableListOf<InsightItem>()

        if (habits.isEmpty()) {
            insights.add(
                InsightItem(
                    id = "empty",
                    title = "Begin Your Rhythm",
                    description = "Add your first habit to unlock personalized behavioral insights and streak analytics.",
                    icon = "star",
                    accentColorHex = "#B6FF00"
                )
            )
            return insights
        }

        // Best weekday insight
        val bestDay = weekdayStats.filter { it.totalLogs > 0 }.maxByOrNull { it.completionPercentage }
        if (bestDay != null && bestDay.completionPercentage > 60) {
            insights.add(
                InsightItem(
                    id = "best_day",
                    title = "Peak Momentum on ${bestDay.dayName}s",
                    description = "You reach ${bestDay.completionPercentage}% habit completion on ${bestDay.dayName}s. Channel this energy into harder tasks.",
                    icon = "bolt",
                    accentColorHex = "#B6FF00"
                )
            )
        }

        // Time of Day comparison insight
        val morningHabits = habits.filter { it.timeOfDay == "MORNING" }.map { it.id }.toSet()
        val eveningHabits = habits.filter { it.timeOfDay == "EVENING" }.map { it.id }.toSet()

        if (morningHabits.isNotEmpty() && eveningHabits.isNotEmpty()) {
            val morningLogs = logs.filter { it.habitId in morningHabits }
            val eveningLogs = logs.filter { it.habitId in eveningHabits }

            val morningRate = if (morningLogs.isNotEmpty()) morningLogs.count { it.status == "COMPLETED" } * 100 / morningLogs.size else 0
            val eveningRate = if (eveningLogs.isNotEmpty()) eveningLogs.count { it.status == "COMPLETED" } * 100 / eveningLogs.size else 0

            if (morningRate > eveningRate && morningRate > 50) {
                val diff = morningRate - eveningRate
                insights.add(
                    InsightItem(
                        id = "morning_momentum",
                        title = "Morning Routine Advantage",
                        description = "Your morning rituals are $diff% more consistent than evening habits. Front-load your critical goals early.",
                        icon = "sun",
                        accentColorHex = "#00E5FF"
                    )
                )
            }
        }

        // Grace day shield insight
        val remainingGrace = (graceDaysLimit - graceDaysUsed).coerceAtLeast(0)
        if (remainingGrace > 0) {
            insights.add(
                InsightItem(
                    id = "grace_shields",
                    title = "$remainingGrace Streak Shield${if (remainingGrace > 1) "s" else ""} Available",
                    description = "Take a guilt-free grace day when rest is needed. Consistency matters more than perfection.",
                    icon = "shield",
                    accentColorHex = "#A855F7"
                )
            )
        }

        // Consistency score
        if (overallConsistency >= 80) {
            insights.add(
                InsightItem(
                    id = "consistency_high",
                    title = "Elite 80%+ Consistency",
                    description = "You are in the top tier of consistency this month. Your identity as a disciplined builder is forming.",
                    icon = "trending_up",
                    accentColorHex = "#FFD60A"
                )
            )
        } else {
            insights.add(
                InsightItem(
                    id = "compound_effort",
                    title = "Small Habits, Big Dividends",
                    description = "Focus on completing just one core anchor habit today to rebuild unstoppable velocity.",
                    icon = "trending_up",
                    accentColorHex = "#FF7A00"
                )
            )
        }

        return insights.take(3)
    }
}
