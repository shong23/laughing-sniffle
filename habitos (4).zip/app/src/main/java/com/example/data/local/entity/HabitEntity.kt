package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.engine.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String = "user_default",
    val name: String,
    val description: String = "",
    val category: String = "Health", // Health, Mind, Focus, Finance, Social, Energy
    val iconName: String = "water_drop",
    val colorHex: String = "#B6FF00",
    val frequencyType: String = "DAILY", // DAILY, WEEKDAYS, SPECIFIC_DAYS, X_PER_WEEK, X_PER_MONTH
    val frequencyConfig: String = "MON,TUE,WED,THU,FRI,SAT,SUN", // e.g. "MON,WED,FRI" or target count "3"
    val targetCount: Int = 1, // e.g. 1 or 4
    val unit: String = "times", // times, glasses, min, pages, km
    val timeOfDay: String = "ANYTIME", // ANYTIME, MORNING, AFTERNOON, EVENING
    val reminderTime: String? = null,
    val startDate: String = "", // YYYY-MM-DD
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val effectiveStartDate: String
        get() {
            if (startDate.isNotBlank()) return startDate
            // Fallback to ISO date formatted from createdAt
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                sdf.format(Date(createdAt))
            } catch (e: Exception) {
                DateUtils.getTodayString()
            }
        }
}
