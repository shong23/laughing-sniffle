package com.example.ui.screens.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.HabitEntity
import com.example.data.repository.HabitRepository
import com.example.domain.engine.DateUtils
import com.example.domain.model.HabitWithStatus
import com.example.util.FeedbackManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TodayUiState(
    val selectedDate: String = DateUtils.getTodayString(),
    val habits: List<HabitWithStatus> = emptyList(),
    val completedCount: Int = 0,
    val totalDueCount: Int = 0,
    val selectedFilter: String = "ALL", // ALL, MORNING, AFTERNOON, EVENING, Health, Mind, Focus, etc.
    val actionHabit: HabitWithStatus? = null,
    val detailHabit: HabitWithStatus? = null,
    val isCreateOpen: Boolean = false,
    val editingHabit: HabitEntity? = null
) {
    val completionRatio: Float
        get() = if (totalDueCount > 0) (completedCount.toFloat() / totalDueCount).coerceIn(0f, 1f) else 0f

    val filteredHabits: List<HabitWithStatus>
        get() = when (selectedFilter) {
            "ALL" -> habits
            "MORNING" -> habits.filter { it.habit.timeOfDay == "MORNING" }
            "AFTERNOON" -> habits.filter { it.habit.timeOfDay == "AFTERNOON" }
            "EVENING" -> habits.filter { it.habit.timeOfDay == "EVENING" }
            else -> habits.filter { it.habit.category.equals(selectedFilter, ignoreCase = true) }
        }
}

@OptIn(ExperimentalCoroutinesApi::class)
class TodayViewModel(
    private val habitRepository: HabitRepository,
    private val feedbackManager: FeedbackManager? = null
) : ViewModel() {

    private val _selectedDate = MutableStateFlow(DateUtils.getTodayString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _selectedFilter = MutableStateFlow("ALL")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _actionHabit = MutableStateFlow<HabitWithStatus?>(null)
    val actionHabit: StateFlow<HabitWithStatus?> = _actionHabit.asStateFlow()

    private val _detailHabit = MutableStateFlow<HabitWithStatus?>(null)
    val detailHabit: StateFlow<HabitWithStatus?> = _detailHabit.asStateFlow()

    private val _isCreateOpen = MutableStateFlow(false)
    val isCreateOpen: StateFlow<Boolean> = _isCreateOpen.asStateFlow()

    private val _editingHabit = MutableStateFlow<HabitEntity?>(null)
    val editingHabit: StateFlow<HabitEntity?> = _editingHabit.asStateFlow()

    val habitsForSelectedDate = _selectedDate.flatMapLatest { date ->
        habitRepository.getHabitsWithStatusForDate(date)
    }

    private data class ModalState(
        val actionHabit: HabitWithStatus?,
        val detailHabit: HabitWithStatus?,
        val isCreateOpen: Boolean,
        val editingHabit: HabitEntity?
    )

    private val _modalState = combine(
        _actionHabit,
        _detailHabit,
        _isCreateOpen,
        _editingHabit
    ) { actionH, detailH, isCreate, editH ->
        ModalState(actionH, detailH, isCreate, editH)
    }

    val uiState: StateFlow<TodayUiState> = combine(
        _selectedDate,
        habitsForSelectedDate,
        _selectedFilter,
        _modalState
    ) { date, habits, filter, modals ->
        val dueHabits = habits.filter { it.isDue }
        val completedCount = dueHabits.count { it.isCompleted || it.isGrace }
        TodayUiState(
            selectedDate = date,
            habits = habits,
            completedCount = completedCount,
            totalDueCount = dueHabits.size,
            selectedFilter = filter,
            actionHabit = modals.actionHabit,
            detailHabit = modals.detailHabit,
            isCreateOpen = modals.isCreateOpen,
            editingHabit = modals.editingHabit
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TodayUiState()
    )

    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun selectFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun openActionSheet(habitWithStatus: HabitWithStatus) {
        _actionHabit.value = habitWithStatus
    }

    fun closeActionSheet() {
        _actionHabit.value = null
    }

    fun openDetailSheet(habitWithStatus: HabitWithStatus) {
        _detailHabit.value = habitWithStatus
    }

    fun closeDetailSheet() {
        _detailHabit.value = null
    }

    fun openCreate(habitToEdit: HabitEntity? = null) {
        _editingHabit.value = habitToEdit
        _isCreateOpen.value = true
    }

    fun closeCreate() {
        _isCreateOpen.value = false
        _editingHabit.value = null
    }

    fun toggleHabit(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            val newlyCompleted = habitRepository.toggleHabit(habitId, _selectedDate.value)
            if (newlyCompleted) {
                feedbackManager?.onHabitCompleted()
            } else {
                feedbackManager?.onHabitUndo()
            }
        }
    }

    fun incrementHabit(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            val completed = habitRepository.incrementHabitValue(habitId, _selectedDate.value)
            if (completed) {
                feedbackManager?.onHabitCompleted()
            } else {
                feedbackManager?.onHabitIncrement()
            }
        }
    }

    fun decrementHabit(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            habitRepository.decrementHabitValue(habitId, _selectedDate.value)
            feedbackManager?.onHabitDecrement()
        }
    }

    fun setGrace(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            habitRepository.setHabitStatus(habitId, _selectedDate.value, "GRACE")
            feedbackManager?.onHabitCompleted()
        }
    }

    fun setSkip(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            habitRepository.setHabitStatus(habitId, _selectedDate.value, "SKIPPED")
            feedbackManager?.onHabitUndo()
        }
    }

    fun undoHabit(habitId: Long) {
        if (DateUtils.isFutureDate(_selectedDate.value)) return
        viewModelScope.launch {
            habitRepository.undoHabit(habitId, _selectedDate.value)
            feedbackManager?.onHabitUndo()
        }
    }

    fun deleteHabit(habitId: Long) {
        viewModelScope.launch {
            habitRepository.deleteHabit(habitId)
        }
    }

    fun saveHabit(habit: HabitEntity) {
        viewModelScope.launch {
            if (habit.id == 0L) {
                habitRepository.createHabit(habit)
            } else {
                habitRepository.updateHabit(habit)
            }
            closeCreate()
        }
    }
}

class TodayViewModelFactory(
    private val repository: HabitRepository,
    private val feedbackManager: FeedbackManager? = null
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TodayViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TodayViewModel(repository, feedbackManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
