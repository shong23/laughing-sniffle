package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.ui.graphics.vector.ImageVector

object HabitIconHelper {
    val availableIcons = listOf(
        "water_drop" to Icons.Default.WaterDrop,
        "brain" to Icons.Default.SelfImprovement,
        "code" to Icons.Default.Code,
        "book" to Icons.Default.MenuBook,
        "fitness" to Icons.Default.FitnessCenter,
        "flame" to Icons.Default.LocalFireDepartment,
        "run" to Icons.Default.DirectionsRun,
        "walk" to Icons.Default.DirectionsWalk,
        "savings" to Icons.Default.Savings,
        "heart" to Icons.Default.Favorite,
        "bedtime" to Icons.Default.Bedtime,
        "coffee" to Icons.Default.LocalCafe,
        "bolt" to Icons.Default.Bolt,
        "sun" to Icons.Default.WbSunny,
        "shield" to Icons.Default.Shield,
        "star" to Icons.Default.Star
    )

    fun getIcon(name: String): ImageVector {
        return availableIcons.find { it.first.equals(name, ignoreCase = true) }?.second
            ?: Icons.Default.WaterDrop
    }
}
