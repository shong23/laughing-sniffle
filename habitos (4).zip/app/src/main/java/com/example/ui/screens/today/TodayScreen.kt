package com.example.ui.screens.today

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.engine.DateUtils
import com.example.ui.components.CircularProgressRing
import com.example.ui.components.DateStrip
import com.example.ui.components.HabitActionBottomSheet
import com.example.ui.components.HabitCard
import com.example.ui.screens.create.CreateHabitSheet
import com.example.ui.screens.detail.HabitDetailSheet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    viewModel: TodayViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val actionSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val detailSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val createSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val filterChips = listOf("ALL", "MORNING", "AFTERNOON", "EVENING", "Health", "Mind", "Focus", "Energy")
    val filterScrollState = rememberScrollState()

    val isDark = MaterialTheme.colorScheme.background.red < 0.5f
    val isFutureDate = DateUtils.isFutureDate(uiState.selectedDate)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openCreate() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .testTag("fab_create_habit")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create Habit",
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 124.dp)
        ) {
            // Header Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = DateUtils.getGreeting(),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = DateUtils.formatDisplayDate(uiState.selectedDate),
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 26.sp
                            )
                        }

                        // Progress ring badge
                        CircularProgressRing(
                            progress = uiState.completionRatio,
                            color = MaterialTheme.colorScheme.primary,
                            size = 52.dp,
                            strokeWidth = 5.dp
                        ) {
                            Text(
                                text = "${uiState.completedCount}/${uiState.totalDueCount}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Minimal motivation / status pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                            )
                            .border(
                                1.dp,
                                if (isDark) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isFutureDate) Icons.Default.Schedule else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isFutureDate) "Scheduled for future date • Complete when day arrives"
                            else if (uiState.totalDueCount == 0) "No scheduled habits for this day"
                            else if (uiState.completedCount == uiState.totalDueCount && uiState.totalDueCount > 0) "All habits completed! Perfect day rhythm."
                            else "${uiState.completedCount} of ${uiState.totalDueCount} habits completed today",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Horizontal Date Strip
            item {
                DateStrip(
                    selectedDate = uiState.selectedDate,
                    onDateSelected = { viewModel.selectDate(it) },
                    accentColor = MaterialTheme.colorScheme.primary
                )
            }

            // Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(filterScrollState)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filterChips.forEach { chip ->
                        val isSelected = uiState.selectedFilter.equals(chip, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .border(
                                    1.dp,
                                    if (isSelected || isDark) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.selectFilter(chip) }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                                .testTag("filter_chip_$chip")
                        ) {
                            Text(
                                text = when (chip) {
                                    "ALL" -> "All Habits"
                                    "MORNING" -> "Morning"
                                    "AFTERNOON" -> "Afternoon"
                                    "EVENING" -> "Evening"
                                    else -> chip
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Habits List
            val filteredHabits = uiState.filteredHabits
            if (filteredHabits.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Nothing scheduled yet.",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Create your first habit to build momentum without friction.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .clickable { viewModel.openCreate() }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)
                                    .testTag("button_empty_create")
                            ) {
                                Text(
                                    text = "Create Habit",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                }
            } else {
                items(
                    items = filteredHabits,
                    key = { it.habit.id }
                ) { habitWithStatus ->
                    Box(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
                    ) {
                        HabitCard(
                            habitWithStatus = habitWithStatus,
                            onToggleCompletion = { viewModel.toggleHabit(habitWithStatus.habit.id) },
                            onIncrement = { viewModel.incrementHabit(habitWithStatus.habit.id) },
                            onDecrement = { viewModel.decrementHabit(habitWithStatus.habit.id) },
                            onLongPress = { viewModel.openActionSheet(habitWithStatus) },
                            onClickCard = { viewModel.openDetailSheet(habitWithStatus) },
                            isFuture = isFutureDate
                        )
                    }
                }
            }
        }

        // Action Sheet
        val actionHabit = uiState.actionHabit
        if (actionHabit != null) {
            HabitActionBottomSheet(
                sheetState = actionSheetState,
                habitWithStatus = actionHabit,
                onDismiss = { viewModel.closeActionSheet() },
                onComplete = { viewModel.toggleHabit(actionHabit.habit.id) },
                onGrace = { viewModel.setGrace(actionHabit.habit.id) },
                onSkip = { viewModel.setSkip(actionHabit.habit.id) },
                onUndo = { viewModel.undoHabit(actionHabit.habit.id) },
                onEdit = {
                    val habit = actionHabit.habit
                    viewModel.openCreate(habit)
                },
                onViewHistory = {
                    viewModel.openDetailSheet(actionHabit)
                },
                onDelete = { viewModel.deleteHabit(actionHabit.habit.id) },
                isFuture = isFutureDate
            )
        }

        // Detail Sheet
        val detailHabit = uiState.detailHabit
        if (detailHabit != null) {
            HabitDetailSheet(
                sheetState = detailSheetState,
                habitWithStatus = detailHabit,
                onDismiss = { viewModel.closeDetailSheet() },
                onEdit = {
                    val habit = detailHabit.habit
                    viewModel.closeDetailSheet()
                    viewModel.openCreate(habit)
                },
                onDelete = {
                    viewModel.deleteHabit(detailHabit.habit.id)
                    viewModel.closeDetailSheet()
                }
            )
        }

        // Create / Edit Modal Sheet
        if (uiState.isCreateOpen) {
            CreateHabitSheet(
                sheetState = createSheetState,
                habitToEdit = uiState.editingHabit,
                onDismiss = { viewModel.closeCreate() },
                onSave = { viewModel.saveHabit(it) }
            )
        }
    }
}
