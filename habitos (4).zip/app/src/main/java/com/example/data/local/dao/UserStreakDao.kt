package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.UserStreakEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserStreakDao {
    @Query("SELECT * FROM user_streaks WHERE habitId = :habitId")
    fun getStreakFlow(habitId: Long): Flow<UserStreakEntity?>

    @Query("SELECT * FROM user_streaks WHERE habitId = :habitId")
    suspend fun getStreak(habitId: Long): UserStreakEntity?

    @Query("SELECT * FROM user_streaks")
    fun getAllStreaksFlow(): Flow<List<UserStreakEntity>>

    @Query("SELECT * FROM user_streaks")
    suspend fun getAllStreaks(): List<UserStreakEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStreak(streak: UserStreakEntity)

    @Query("DELETE FROM user_streaks WHERE habitId = :habitId")
    suspend fun deleteStreak(habitId: Long)
}
