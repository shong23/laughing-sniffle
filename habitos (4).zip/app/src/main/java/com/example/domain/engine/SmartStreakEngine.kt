package com.example.domain.engine

import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.UserStreakEntity

object SmartStreakEngine {

    fun calculateStreak(
        habit: HabitEntity,
        logs: List<HabitLogEntity>,
        monthlyGraceLimit: Int = 2,
        anchorDate: String = DateUtils.getTodayString()
    ): UserStreakEntity {
        val logMap = logs.associateBy { it.date }
        val currentMonthPrefix = DateUtils.getYearMonth(anchorDate)
        val startDate = habit.effectiveStartDate
        
        val graceDaysUsedThisMonth = logs.count {
            it.status == "GRACE" && it.date.startsWith(currentMonthPrefix)
        }

        val totalCompletions = logs.count { it.status == "COMPLETED" || it.value >= habit.targetCount }

        // Find last completed date
        val lastCompleted = logs
            .filter { it.status == "COMPLETED" || it.value >= habit.targetCount }
            .maxByOrNull { it.date }
            ?.date

        // Calculate Current Streak
        var currentStreak = 0
        var checkDate = anchorDate
        var checkedDays = 0
        val maxLookback = 365

        // If today is due and not completed yet, check if yesterday was completed to keep active streak counting
        val todayLog = logMap[anchorDate]
        val todayIsCompleted = todayLog != null && (todayLog.status == "COMPLETED" || todayLog.status == "GRACE" || todayLog.value >= habit.targetCount)
        val todayIsDue = SchedulingEngine.isHabitDueOnDate(habit, anchorDate)

        if (!todayIsCompleted && todayIsDue) {
            checkDate = DateUtils.addDays(anchorDate, -1)
        }

        while (checkedDays < maxLookback) {
            if (startDate.isNotBlank() && checkDate < startDate) {
                // Reached prior to creation day; streak starts from creation day
                break
            }

            val isDue = SchedulingEngine.isHabitDueOnDate(habit, checkDate)
            if (isDue) {
                val log = logMap[checkDate]
                if (log != null && (log.status == "COMPLETED" || log.status == "GRACE" || log.value >= habit.targetCount)) {
                    currentStreak++
                } else if (log != null && log.status == "SKIPPED") {
                    // Skipped does not increment but doesn't break
                } else {
                    // Break streak
                    break
                }
            }
            checkDate = DateUtils.addDays(checkDate, -1)
            checkedDays++
        }

        // Calculate Longest Streak
        var longestStreak = currentStreak
        val pastDays = DateUtils.getPastDays(180, includeToday = true).filter {
            startDate.isBlank() || it >= startDate
        }
        var runningStreak = 0

        for (day in pastDays) {
            val isDue = SchedulingEngine.isHabitDueOnDate(habit, day)
            if (isDue) {
                val log = logMap[day]
                if (log != null && (log.status == "COMPLETED" || log.status == "GRACE" || log.value >= habit.targetCount)) {
                    runningStreak++
                    if (runningStreak > longestStreak) {
                        longestStreak = runningStreak
                    }
                } else if (log != null && log.status == "SKIPPED") {
                    // neutral
                } else {
                    runningStreak = 0
                }
            }
        }

        // Calculate 30-day Completion Rate (only on days since habit started)
        val past30Days = DateUtils.getPastDays(30, includeToday = true).filter {
            startDate.isBlank() || it >= startDate
        }
        var dueCount30 = 0
        var completedCount30 = 0

        for (day in past30Days) {
            if (SchedulingEngine.isHabitDueOnDate(habit, day)) {
                dueCount30++
                val log = logMap[day]
                if (log != null && (log.status == "COMPLETED" || log.value >= habit.targetCount)) {
                    completedCount30++
                }
            }
        }

        val completionRate = if (dueCount30 > 0) {
            completedCount30.toFloat() / dueCount30
        } else if (totalCompletions > 0) 1.0f else 0f

        return UserStreakEntity(
            habitId = habit.id,
            currentStreak = currentStreak,
            longestStreak = maxOf(longestStreak, currentStreak),
            totalCompletions = totalCompletions,
            graceDaysUsedMonth = graceDaysUsedThisMonth,
            lastCompletedDate = lastCompleted,
            completionRate = completionRate,
            updatedAt = System.currentTimeMillis()
        )
    }
}
