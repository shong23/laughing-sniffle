package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.data.local.dao.UserSettingsDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * High-performance feedback engine for tactile haptics and subtle synthesized audio tones.
 * Respects user preferences in UserSettingsEntity (soundEnabled & hapticsEnabled).
 */
class FeedbackManager(
    private val context: Context,
    private val userSettingsDao: UserSettingsDao? = null
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    @Volatile
    private var isSoundEnabled: Boolean = true

    @Volatile
    private var isHapticsEnabled: Boolean = true

    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
        } catch (e: Exception) {
            Log.w("FeedbackManager", "Unable to create ToneGenerator: ${e.message}")
        }

        // Initialize and listen to settings
        userSettingsDao?.let { dao ->
            scope.launch {
                dao.getSettingsFlow().collect { settings ->
                    if (settings != null) {
                        isSoundEnabled = settings.soundEnabled
                        isHapticsEnabled = settings.hapticsEnabled
                    }
                }
            }
        }
    }

    fun updateSettings(soundEnabled: Boolean, hapticsEnabled: Boolean) {
        this.isSoundEnabled = soundEnabled
        this.isHapticsEnabled = hapticsEnabled
    }

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Triggered when a habit is completed (100% or checked off).
     * Delivers a rewarding, crisp tone and a satisfying double-click haptic pulse.
     */
    fun onHabitCompleted() {
        if (isSoundEnabled) {
            playTone(ToneGenerator.TONE_PROP_ACK, 120)
        }
        if (isHapticsEnabled) {
            vibrateSuccess()
        }
    }

    /**
     * Triggered on numeric habit increment (+1 step).
     * Delivers a snappy, minimal tick feedback.
     */
    fun onHabitIncrement() {
        if (isSoundEnabled) {
            playTone(ToneGenerator.TONE_PROP_BEEP, 50)
        }
        if (isHapticsEnabled) {
            vibrateTick()
        }
    }

    /**
     * Triggered on habit decrement (-1 step).
     * Delivers a soft low feedback tone and subtle tick.
     */
    fun onHabitDecrement() {
        if (isSoundEnabled) {
            playTone(ToneGenerator.TONE_PROP_BEEP2, 40)
        }
        if (isHapticsEnabled) {
            vibrateTick()
        }
    }

    /**
     * Triggered when a completed habit is undone / toggled off.
     * Delivers a subtle descending cancellation feel.
     */
    fun onHabitUndo() {
        if (isSoundEnabled) {
            playTone(ToneGenerator.TONE_PROP_NACK, 70)
        }
        if (isHapticsEnabled) {
            vibrateUndo()
        }
    }

    private fun playTone(toneType: Int, durationMs: Int) {
        scope.launch(Dispatchers.Default) {
            try {
                if (toneGenerator == null) {
                    toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
                }
                toneGenerator?.startTone(toneType, durationMs)
            } catch (e: Exception) {
                Log.w("FeedbackManager", "Error playing tone: ${e.message}")
            }
        }
    }

    private fun vibrateSuccess() {
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Double tap pulse
                val effect = VibrationEffect.createWaveform(
                    longArrayOf(0, 35, 60, 45),
                    intArrayOf(0, 200, 0, 255),
                    -1
                )
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(longArrayOf(0, 35, 60, 45), -1)
            }
        } catch (_: Exception) {}
    }

    private fun vibrateTick() {
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val effect = VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(20)
            }
        } catch (_: Exception) {}
    }

    private fun vibrateUndo() {
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val effect = VibrationEffect.createWaveform(
                    longArrayOf(0, 25, 40, 25),
                    intArrayOf(0, 140, 0, 100),
                    -1
                )
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(longArrayOf(0, 25, 40, 25), -1)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }
}
