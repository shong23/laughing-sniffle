package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String, // unique user ID (e.g. email, google ID, or UUID)
    val email: String,
    val displayName: String,
    val authProvider: String = "EMAIL", // "GOOGLE" or "EMAIL"
    val avatarColorHex: String = "#B6FF00",
    val hasCompletedTour: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
