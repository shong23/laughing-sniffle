package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import java.util.Calendar

/**
 * Lightweight notification scheduler for daily morning motivation and time-of-day habit prompts.
 * Respects user preferences in UserSettingsEntity.
 */
object NotificationScheduler {
    const val CHANNEL_ID = "rhythm_habit_reminders"
    const val CHANNEL_NAME = "Habit Reminders"
    const val CHANNEL_DESC = "Daily motivation and time-of-day habit prompts"

    const val EXTRA_TITLE = "extra_reminder_title"
    const val EXTRA_MESSAGE = "extra_reminder_message"
    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"

    const val REQUEST_CODE_MORNING = 1001
    const val REQUEST_CODE_AFTERNOON = 1002
    const val REQUEST_CODE_EVENING = 1003

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = CHANNEL_DESC
                enableLights(true)
                enableVibration(true)
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun syncReminders(context: Context, isEnabled: Boolean) {
        createNotificationChannel(context)

        if (!isEnabled) {
            cancelAllReminders(context)
            return
        }

        // Schedule Morning Prompt (8:00 AM)
        scheduleDailyAlarm(
            context = context,
            requestCode = REQUEST_CODE_MORNING,
            hour = 8,
            minute = 0,
            title = "🌅 Morning Momentum",
            message = "Start your day strong! Check off your morning habits."
        )

        // Schedule Afternoon Prompt (1:30 PM)
        scheduleDailyAlarm(
            context = context,
            requestCode = REQUEST_CODE_AFTERNOON,
            hour = 13,
            minute = 30,
            title = "⚡ Afternoon Focus",
            message = "Keep your streaks alive. Review your afternoon goals."
        )

        // Schedule Evening Prompt (8:00 PM)
        scheduleDailyAlarm(
            context = context,
            requestCode = REQUEST_CODE_EVENING,
            hour = 20,
            minute = 0,
            title = "🌙 Evening Reflection",
            message = "Lock in today's rhythm and prepare for tomorrow."
        )
    }

    private fun scheduleDailyAlarm(
        context: Context,
        requestCode: Int,
        hour: Int,
        minute: Int,
        title: String,
        message: String
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, HabitReminderReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_NOTIFICATION_ID, requestCode)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // If time has already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
                )
            }
            Log.d("NotificationScheduler", "Scheduled reminder ($requestCode) for ${calendar.time}")
        } catch (e: SecurityException) {
            // Fallback for devices restricting exact alarms
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        } catch (e: Exception) {
            Log.w("NotificationScheduler", "Failed to schedule alarm: ${e.message}")
        }
    }

    fun cancelAllReminders(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        listOf(REQUEST_CODE_MORNING, REQUEST_CODE_AFTERNOON, REQUEST_CODE_EVENING).forEach { requestCode ->
            val intent = Intent(context, HabitReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }
}
