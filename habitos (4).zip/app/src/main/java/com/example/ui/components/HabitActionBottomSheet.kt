package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.HabitWithStatus
import com.example.ui.theme.AccentGrace
import com.example.ui.theme.parseColorHex

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HabitActionBottomSheet(
    sheetState: SheetState,
    habitWithStatus: HabitWithStatus,
    onDismiss: () -> Unit,
    onComplete: () -> Unit,
    onGrace: () -> Unit,
    onSkip: () -> Unit,
    onUndo: () -> Unit,
    onEdit: () -> Unit,
    onViewHistory: () -> Unit,
    onDelete: () -> Unit,
    isFuture: Boolean = false
) {
    val habit = habitWithStatus.habit
    val accentColor = parseColorHex(habit.colorHex)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        scrimColor = Color.Black.copy(alpha = 0.6f),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            // Header Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = HabitIconHelper.getIcon(habit.iconName),
                        contentDescription = habit.name,
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = habit.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${habit.category} • Target: ${habit.targetCount} ${habit.unit}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            // Action Items
            if (!isFuture) {
                if (!habitWithStatus.isCompleted) {
                    ActionItem(
                        icon = Icons.Default.CheckCircle,
                        title = "Mark as Completed",
                        subtitle = "Instantly record full target count",
                        iconTint = accentColor,
                        onClick = {
                            onComplete()
                            onDismiss()
                        },
                        testTag = "action_complete"
                    )
                } else {
                    ActionItem(
                        icon = Icons.Default.Refresh,
                        title = "Undo Completion",
                        subtitle = "Reset progress for this date",
                        iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                        onClick = {
                            onUndo()
                            onDismiss()
                        },
                        testTag = "action_undo"
                    )
                }

                ActionItem(
                    icon = Icons.Default.Shield,
                    title = "Use Grace Shield",
                    subtitle = "Protect your streak without guilt (2/mo)",
                    iconTint = AccentGrace,
                    onClick = {
                        onGrace()
                        onDismiss()
                    },
                    testTag = "action_grace"
                )

                ActionItem(
                    icon = Icons.Default.FastForward,
                    title = "Skip Today",
                    subtitle = "Pause habit today without streak penalty",
                    iconTint = Color(0xFFFFD60A),
                    onClick = {
                        onSkip()
                        onDismiss()
                    },
                    testTag = "action_skip"
                )
            }

            ActionItem(
                icon = Icons.Default.History,
                title = "View History & Insights",
                subtitle = "Detailed calendar logs and streak records",
                iconTint = MaterialTheme.colorScheme.onSurface,
                onClick = {
                    onViewHistory()
                    onDismiss()
                },
                testTag = "action_history"
            )

            ActionItem(
                icon = Icons.Default.Edit,
                title = "Edit Habit Details",
                subtitle = "Update frequency, target count, or color",
                iconTint = MaterialTheme.colorScheme.onSurface,
                onClick = {
                    onEdit()
                    onDismiss()
                },
                testTag = "action_edit"
            )

            ActionItem(
                icon = Icons.Default.Delete,
                title = "Delete Habit",
                subtitle = "Remove habit and associated logs",
                iconTint = Color(0xFFEF4444),
                onClick = {
                    onDelete()
                    onDismiss()
                },
                testTag = "action_delete"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ActionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconTint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 8.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
