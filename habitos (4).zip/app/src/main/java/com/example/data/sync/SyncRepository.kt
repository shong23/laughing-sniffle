package com.example.data.sync

import com.example.data.local.dao.HabitDao
import com.example.data.local.dao.HabitLogDao
import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.dao.UserStreakDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

/**
 * Backward compatibility wrapper for FirestoreSyncRepository
 */
typealias SyncRepository = FirestoreSyncRepository
