package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.HabitWithStatus
import com.example.ui.theme.AccentGrace
import com.example.ui.theme.getCardBackgroundBrush
import com.example.ui.theme.getComfortableAccentTextColor
import com.example.ui.theme.parseColorHex

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HabitCard(
    habitWithStatus: HabitWithStatus,
    onToggleCompletion: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onLongPress: () -> Unit,
    onClickCard: () -> Unit,
    modifier: Modifier = Modifier,
    isFuture: Boolean = false
) {
    val habit = habitWithStatus.habit
    val isCompleted = habitWithStatus.isCompleted
    val isGrace = habitWithStatus.isGrace
    val isSkipped = habitWithStatus.isSkipped
    val accentColor = parseColorHex(habit.colorHex)
    val isDark = MaterialTheme.colorScheme.background.red < 0.5f
    val comfortableAccent = getComfortableAccentTextColor(accentColor, isDark)
    val streakCount = habitWithStatus.streak?.currentStreak ?: 0

    val view = LocalView.current
    var isPressed by remember { mutableStateOf(false) }

    val cardScale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "CardScale"
    )

    val cardBrush = remember(isDark, isCompleted, isGrace, accentColor) {
        com.example.ui.theme.getCardBackgroundBrush(isDark, isCompleted, isGrace, accentColor)
    }

    val borderColor by animateColorAsState(
        targetValue = when {
            isCompleted -> if (isDark) accentColor.copy(alpha = 0.35f) else comfortableAccent.copy(alpha = 0.28f)
            isGrace -> if (isDark) AccentGrace.copy(alpha = 0.5f) else AccentGrace.copy(alpha = 0.35f)
            else -> MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.4f else 0.7f)
        },
        label = "CardBorderColor"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(cardScale)
            .clip(RoundedCornerShape(20.dp))
            .background(cardBrush)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .combinedClickable(
                onClick = onClickCard,
                onLongClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onLongPress()
                }
            )
            .padding(16.dp)
            .testTag("habit_card_${habit.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Icon + Habit Details
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Category Icon with subtle tinted background & light gradient
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(
                                    accentColor.copy(alpha = if (isDark) 0.25f else 0.22f),
                                    accentColor.copy(alpha = if (isDark) 0.12f else 0.08f)
                                )
                            )
                        )
                        .border(
                            0.5.dp,
                            if (isDark) accentColor.copy(alpha = 0.3f) else comfortableAccent.copy(alpha = 0.25f),
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = HabitIconHelper.getIcon(habit.iconName),
                        contentDescription = habit.name,
                        tint = if (isDark) accentColor else comfortableAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = habit.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurface,
                            textDecoration = if (isSkipped) TextDecoration.LineThrough else TextDecoration.None,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Target / Progress label
                        if (habit.targetCount > 1) {
                            Text(
                                text = "${habitWithStatus.currentValue} / ${habit.targetCount} ${habit.unit}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isCompleted) (if (isDark) accentColor else comfortableAccent) else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (isCompleted) FontWeight.SemiBold else FontWeight.Normal
                            )
                        } else {
                            Text(
                                text = when {
                                    isGrace -> "Shielded Grace"
                                    isSkipped -> "Skipped today"
                                    isCompleted -> "Completed"
                                    else -> habit.category
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = when {
                                    isGrace -> if (isDark) AccentGrace else Color(0xFF5B21B6)
                                    isCompleted -> if (isDark) accentColor else comfortableAccent
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }

                        // Streak badge if > 0
                        if (streakCount > 0) {
                            val streakAmber = if (isDark) Color(0xFFFF7A00) else Color(0xFFC2410C)
                            val streakBgColor = if (isGrace) {
                                if (isDark) AccentGrace.copy(alpha = 0.2f) else AccentGrace.copy(alpha = 0.12f)
                            } else {
                                if (isDark) Color(0xFFFF7A00).copy(alpha = 0.15f) else Color(0xFFFF7A00).copy(alpha = 0.12f)
                            }
                            val streakIconColor = if (isGrace) (if (isDark) AccentGrace else Color(0xFF5B21B6)) else streakAmber

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(streakBgColor)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isGrace) Icons.Default.Shield else Icons.Default.LocalFireDepartment,
                                        contentDescription = "Streak",
                                        tint = streakIconColor,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "$streakCount",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = streakIconColor,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Right: Future date Scheduled Indicator OR Multi-count Stepper OR Single-Tap Completion Button
            if (isFuture) {
                // Scheduled Status Indicator for future dates
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (isDark) 0.4f else 0.6f))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.25f else 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("habit_scheduled_${habit.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Scheduled",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Scheduled",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }
                }
            } else if (habit.targetCount > 1 && !isCompleted) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (habitWithStatus.currentValue > 0) {
                        IconButton(
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                onDecrement()
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("habit_decrement_${habit.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = "Decrease",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onIncrement()
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.2f))
                            .border(1.5.dp, accentColor, CircleShape)
                            .testTag("habit_increment_${habit.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Increase",
                            tint = accentColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            } else {
                // One-Tap Checkmark Button
                val buttonBgColor by animateColorAsState(
                    targetValue = when {
                        isCompleted -> accentColor
                        isGrace -> AccentGrace
                        else -> Color.Transparent
                    },
                    animationSpec = tween(300, easing = FastOutSlowInEasing),
                    label = "CheckBgColor"
                )

                val buttonBorderColor by animateColorAsState(
                    targetValue = when {
                        isCompleted -> accentColor
                        isGrace -> AccentGrace
                        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                    },
                    label = "CheckBorderColor"
                )

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(buttonBgColor)
                        .border(2.dp, buttonBorderColor, CircleShape)
                        .combinedClickable(
                            onClick = {
                                view.performHapticFeedback(
                                    if (!isCompleted) HapticFeedbackConstants.CONFIRM
                                    else HapticFeedbackConstants.CLOCK_TICK
                                )
                                onToggleCompletion()
                            }
                        )
                        .testTag("habit_toggle_${habit.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = isCompleted,
                        enter = scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
                        exit = scaleOut() + fadeOut()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = isGrace && !isCompleted,
                        enter = scaleIn() + fadeIn(),
                        exit = scaleOut() + fadeOut()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Grace shield",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
