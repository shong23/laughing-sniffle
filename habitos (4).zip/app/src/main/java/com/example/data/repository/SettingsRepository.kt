package com.example.data.repository

import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.sync.FirestoreSyncRepository
import kotlinx.coroutines.flow.Flow

class SettingsRepository(
    private val userSettingsDao: UserSettingsDao,
    private val authRepository: AuthRepository? = null,
    private val syncRepository: FirestoreSyncRepository? = null
) {
    val settingsFlow: Flow<UserSettingsEntity?> = userSettingsDao.getSettingsFlow()

    private val currentUserId: String
        get() = authRepository?.currentUserId ?: "user_default"

    suspend fun getSettings(): UserSettingsEntity {
        var settings = userSettingsDao.getSettings()
        if (settings == null) {
            settings = UserSettingsEntity(userId = currentUserId)
            userSettingsDao.saveSettings(settings)
        }
        return settings
    }

    private suspend fun persistAndSync(updated: UserSettingsEntity) {
        userSettingsDao.updateSettings(updated)
        syncRepository?.syncSettingsUp(currentUserId, updated)
    }

    suspend fun updateThemeMode(themeMode: String) {
        val current = getSettings()
        persistAndSync(current.copy(themeMode = themeMode))
    }

    suspend fun updateGraceDaysLimit(limit: Int) {
        val current = getSettings()
        persistAndSync(current.copy(graceDaysPerMonth = limit))
    }

    suspend fun updateHaptics(enabled: Boolean) {
        val current = getSettings()
        persistAndSync(current.copy(hapticsEnabled = enabled))
    }

    suspend fun updateSound(enabled: Boolean) {
        val current = getSettings()
        persistAndSync(current.copy(soundEnabled = enabled))
    }

    suspend fun updateWeekStart(startMonday: Boolean) {
        val current = getSettings()
        persistAndSync(current.copy(weekStartMonday = startMonday))
    }

    suspend fun updateReminderNotifications(enabled: Boolean) {
        val current = getSettings()
        persistAndSync(current.copy(reminderNotifications = enabled))
    }

    suspend fun completeOnboarding() {
        val current = getSettings()
        persistAndSync(current.copy(onboardingCompleted = true))
    }

    suspend fun resetOnboarding() {
        val current = getSettings()
        persistAndSync(current.copy(onboardingCompleted = false))
    }
}
