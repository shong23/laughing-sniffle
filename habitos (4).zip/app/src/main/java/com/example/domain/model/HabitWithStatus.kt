package com.example.domain.model

import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.UserStreakEntity

data class HabitWithStatus(
    val habit: HabitEntity,
    val log: HabitLogEntity?, // Log for selected date
    val streak: UserStreakEntity?,
    val isDue: Boolean,
    val currentValue: Int, // e.g. 2
    val targetValue: Int, // e.g. 4
    val isCompleted: Boolean,
    val isSkipped: Boolean,
    val isGrace: Boolean
) {
    val progress: Float
        get() = if (targetValue > 0) (currentValue.toFloat() / targetValue).coerceIn(0f, 1f) else 0f
}
