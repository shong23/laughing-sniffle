package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_streaks")
data class UserStreakEntity(
    @PrimaryKey
    val habitId: Long,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val totalCompletions: Int = 0,
    val graceDaysUsedMonth: Int = 0,
    val lastCompletedDate: String? = null,
    val completionRate: Float = 0f,
    val updatedAt: Long = System.currentTimeMillis()
)
