package com.example.domain.model

import androidx.compose.ui.graphics.Color

data class CategoryMeta(
    val name: String,
    val color: Color,
    val colorHex: String,
    val defaultIcon: String
)

object HabitCategories {
    val Health = CategoryMeta("Health", Color(0xFFB6FF00), "#B6FF00", "water_drop")
    val Mind = CategoryMeta("Mind", Color(0xFFA855F7), "#A855F7", "brain")
    val Focus = CategoryMeta("Focus", Color(0xFF00E5FF), "#00E5FF", "code")
    val Finance = CategoryMeta("Finance", Color(0xFFFFD60A), "#FFD60A", "savings")
    val Social = CategoryMeta("Social", Color(0xFFFF4D8D), "#FF4D8D", "heart")
    val Energy = CategoryMeta("Energy", Color(0xFFFF7A00), "#FF7A00", "flame")

    val all = listOf(Health, Mind, Focus, Finance, Social, Energy)

    fun fromName(name: String): CategoryMeta {
        return all.find { it.name.equals(name, ignoreCase = true) } ?: Health
    }
}
