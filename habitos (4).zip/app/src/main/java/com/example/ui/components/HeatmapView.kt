package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.DateUtils
import com.example.domain.model.HeatmapDay

@Composable
fun HeatmapView(
    heatmapDays: List<HeatmapDay>,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    var selectedDay by remember { mutableStateOf<HeatmapDay?>(null) }
    val scrollState = rememberScrollState()

    // Organize days into columns of 7 (Monday = row 0 ... Sunday = row 6)
    // heatmapDays is a continuous list of days
    val weeks = remember(heatmapDays) {
        val weekList = mutableListOf<List<HeatmapDay>>()
        var currentWeek = mutableListOf<HeatmapDay>()

        heatmapDays.forEach { day ->
            currentWeek.add(day)
            if (currentWeek.size == 7) {
                weekList.add(currentWeek)
                currentWeek = mutableListOf()
            }
        }
        if (currentWeek.isNotEmpty()) {
            weekList.add(currentWeek)
        }
        weekList
    }

    val isDark = MaterialTheme.colorScheme.background.red < 0.5f
    val emptyCellColor = if (isDark) Color(0xFF202532) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
    val activeBorderColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.4f else 0.7f), RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("heatmap_container")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Rhythm Consistency Matrix",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Past 12 weeks of daily momentum",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Legend indicators
            Row(
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Less", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                CellLegendBox(emptyCellColor)
                CellLegendBox(accentColor.copy(alpha = if (isDark) 0.35f else 0.4f))
                CellLegendBox(accentColor.copy(alpha = if (isDark) 0.65f else 0.7f))
                CellLegendBox(accentColor)
                Text("More", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid of squares
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Day of week labels
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(end = 4.dp)
            ) {
                val labels = listOf("M", "", "W", "", "F", "", "S")
                labels.forEach { l ->
                    Box(
                        modifier = Modifier.size(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = l,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    }
                }
            }

            // Weeks columns
            weeks.forEach { week ->
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    week.forEach { day ->
                        val cellColor = when {
                            day.completionRatio == 0f -> emptyCellColor
                            day.completionRatio < 0.4f -> accentColor.copy(alpha = if (isDark) 0.35f else 0.4f)
                            day.completionRatio < 0.8f -> accentColor.copy(alpha = if (isDark) 0.65f else 0.7f)
                            else -> accentColor
                        }

                        val isCellSelected = selectedDay?.date == day.date

                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(cellColor)
                                .then(
                                    if (day.isToday || isCellSelected) {
                                        Modifier.border(1.5.dp, activeBorderColor, RoundedCornerShape(4.dp))
                                    } else Modifier
                                )
                                .clickable { selectedDay = day }
                        )
                    }
                }
            }
        }

        // Active day tooltip info
        val activeDay = selectedDay ?: heatmapDays.lastOrNull()
        if (activeDay != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = DateUtils.formatDisplayDate(activeDay.date),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "${activeDay.completedCount} completed • ${(activeDay.completionRatio * 100).toInt()}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) accentColor else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun CellLegendBox(color: Color) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(color)
    )
}
