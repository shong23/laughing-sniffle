package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.WeekdayStat

@Composable
fun WeeklyBarChart(
    weekdayStats: List<WeekdayStat>,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    val highestPct = weekdayStats.maxOfOrNull { it.completionPercentage } ?: 0
    val isDark = MaterialTheme.colorScheme.background.red < 0.5f
    val peakTextColor = if (isDark) accentColor else MaterialTheme.colorScheme.primary

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.4f else 0.7f), RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("weekly_barchart")
    ) {
        Column {
            Text(
                text = "Weekly Distribution",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Consistency patterns by day of week",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            weekdayStats.forEach { stat ->
                val isPeak = stat.completionPercentage > 0 && stat.completionPercentage == highestPct

                val animatedRatio by animateFloatAsState(
                    targetValue = (stat.completionPercentage / 100f).coerceIn(0.06f, 1f),
                    animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
                    label = "BarHeight_${stat.dayName}"
                )

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    // Value label on top
                    Text(
                        text = if (stat.completionPercentage > 0) "${stat.completionPercentage}%" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPeak) peakTextColor else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isPeak) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Bar Track & Fill
                    Box(
                        modifier = Modifier
                            .width(22.dp)
                            .height(84.dp)
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = 4.dp, bottomEnd = 4.dp))
                            .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(animatedRatio)
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                .background(
                                    if (isPeak) {
                                        Brush.verticalGradient(
                                            listOf(accentColor, accentColor.copy(alpha = if (isDark) 0.7f else 0.85f))
                                        )
                                    } else {
                                        Brush.verticalGradient(
                                            listOf(accentColor.copy(alpha = if (isDark) 0.5f else 0.65f), accentColor.copy(alpha = if (isDark) 0.25f else 0.35f))
                                        )
                                    }
                                )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Day label
                    Text(
                        text = stat.dayName,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isPeak) FontWeight.Bold else FontWeight.Medium,
                        color = if (isPeak) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
