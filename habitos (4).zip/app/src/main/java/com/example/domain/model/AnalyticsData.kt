package com.example.domain.model

data class HeatmapDay(
    val date: String, // YYYY-MM-DD
    val dayOfWeek: Int, // 1 = Monday ... 7 = Sunday
    val completionRatio: Float, // 0.0 to 1.0
    val completedCount: Int,
    val totalDueCount: Int,
    val isToday: Boolean = false
)

data class WeekdayStat(
    val dayName: String, // Mon, Tue, etc.
    val completionPercentage: Int, // 0 - 100
    val totalLogs: Int,
    val completedLogs: Int
)

data class InsightItem(
    val id: String,
    val title: String,
    val description: String,
    val icon: String, // "trending_up", "shield", "bolt", "star"
    val accentColorHex: String
)

data class HabitPerformance(
    val habitId: Long,
    val habitName: String,
    val category: String,
    val colorHex: String,
    val iconName: String,
    val currentStreak: Int,
    val longestStreak: Int,
    val completionRate: Float, // 0.0 to 1.0
    val totalCompletions: Int
)

data class AnalyticsSummary(
    val overallConsistency: Int, // e.g. 87%
    val monthDelta: Int, // e.g. +8%
    val totalCompletionsAllTime: Int,
    val perfectDaysCount: Int,
    val activeHabitsCount: Int,
    val currentBestStreak: Int,
    val graceDaysUsedThisMonth: Int,
    val graceDaysLimit: Int,
    val heatmapDays: List<HeatmapDay>,
    val weekdayStats: List<WeekdayStat>,
    val topHabits: List<HabitPerformance>,
    val insights: List<InsightItem>
)
