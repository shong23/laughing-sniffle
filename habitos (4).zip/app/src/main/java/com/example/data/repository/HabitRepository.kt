package com.example.data.repository

import com.example.data.local.dao.HabitDao
import com.example.data.local.dao.HabitLogDao
import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.dao.UserStreakDao
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.UserStreakEntity
import com.example.data.sync.SyncRepository
import com.example.domain.engine.DateUtils
import com.example.domain.engine.InsightsEngine
import com.example.domain.engine.SchedulingEngine
import com.example.domain.engine.SmartStreakEngine
import com.example.domain.model.AnalyticsSummary
import com.example.domain.model.HabitPerformance
import com.example.domain.model.HabitWithStatus
import com.example.domain.model.HeatmapDay
import com.example.domain.model.WeekdayStat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

class HabitRepository(
    private val habitDao: HabitDao,
    private val habitLogDao: HabitLogDao,
    private val userStreakDao: UserStreakDao,
    private val userSettingsDao: UserSettingsDao,
    private val authRepository: AuthRepository? = null,
    private val syncRepository: SyncRepository? = null,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val currentUserId: String
        get() = authRepository?.currentUserId ?: "user_default"

    init {
        // Automatically start real-time cloud synchronization whenever an authenticated user signs in
        authRepository?.let { auth ->
            scope.launch {
                auth.currentUser.collect { user ->
                    if (user != null && user.id.isNotBlank() && user.id != "guest_user") {
                        syncRepository?.startSyncForUser(user.id)
                    } else {
                        syncRepository?.stopSync()
                    }
                }
            }
        }
    }

    val activeHabits: Flow<List<HabitEntity>>
        get() = if (authRepository != null) {
            authRepository.currentUser.flatMapLatest { user ->
                val uid = user?.id ?: "guest"
                habitDao.getActiveHabits(uid)
            }
        } else {
            habitDao.getActiveHabits()
        }

    val allLogs: Flow<List<HabitLogEntity>> = habitLogDao.getAllLogs()
    val allStreaks: Flow<List<UserStreakEntity>> = userStreakDao.getAllStreaksFlow()
    val userSettings: Flow<UserSettingsEntity?> = userSettingsDao.getSettingsFlow()

    fun getHabitsWithStatusForDate(isoDate: String): Flow<List<HabitWithStatus>> {
        val habitsFlow = if (authRepository != null) {
            authRepository.currentUser.flatMapLatest { user ->
                val uid = user?.id ?: "guest"
                habitDao.getActiveHabits(uid)
            }
        } else {
            habitDao.getActiveHabits()
        }

        return combine(
            habitsFlow,
            habitLogDao.getLogsForDate(isoDate),
            userStreakDao.getAllStreaksFlow()
        ) { habits, logs, streaks ->
            val logMap = logs.associateBy { it.habitId }
            val streakMap = streaks.associateBy { it.habitId }

            habits.filter { habit ->
                val log = logMap[habit.id]
                log != null || habit.effectiveStartDate <= isoDate
            }.map { habit ->
                val log = logMap[habit.id]
                val streak = streakMap[habit.id]
                val isDue = SchedulingEngine.isHabitDueOnDate(habit, isoDate)
                val currentValue = log?.value ?: 0
                val targetValue = habit.targetCount
                val isCompleted = log?.status == "COMPLETED" || (targetValue > 0 && currentValue >= targetValue)
                val isSkipped = log?.status == "SKIPPED"
                val isGrace = log?.status == "GRACE"

                HabitWithStatus(
                    habit = habit,
                    log = log,
                    streak = streak,
                    isDue = isDue,
                    currentValue = currentValue,
                    targetValue = targetValue,
                    isCompleted = isCompleted,
                    isSkipped = isSkipped,
                    isGrace = isGrace
                )
            }
        }
    }

    suspend fun toggleHabit(habitId: Long, date: String): Boolean {
        if (DateUtils.isFutureDate(date)) return false
        val habit = habitDao.getHabitById(habitId) ?: return false
        val currentLog = habitLogDao.getLogForHabitAndDate(habitId, date)

        val isNewlyCompleted: Boolean
        if (currentLog == null) {
            val newLog = HabitLogEntity(
                habitId = habitId,
                date = date,
                status = "COMPLETED",
                value = habit.targetCount,
                completedAt = System.currentTimeMillis()
            )
            habitLogDao.insertLog(newLog)
            syncRepository?.syncLogUp(currentUserId, newLog)
            isNewlyCompleted = true
        } else if (currentLog.status == "COMPLETED" || currentLog.value >= habit.targetCount) {
            habitLogDao.deleteLog(habitId, date)
            syncRepository?.deleteLogRemote(currentUserId, habitId, date)
            isNewlyCompleted = false
        } else {
            val updatedLog = currentLog.copy(
                status = "COMPLETED",
                value = habit.targetCount,
                completedAt = System.currentTimeMillis()
            )
            habitLogDao.insertLog(updatedLog)
            syncRepository?.syncLogUp(currentUserId, updatedLog)
            isNewlyCompleted = true
        }

        recalculateStreak(habit)
        return isNewlyCompleted
    }

    suspend fun incrementHabitValue(habitId: Long, date: String): Boolean {
        if (DateUtils.isFutureDate(date)) return false
        val habit = habitDao.getHabitById(habitId) ?: return false
        val currentLog = habitLogDao.getLogForHabitAndDate(habitId, date)

        val nextVal = (currentLog?.value ?: 0) + 1
        val isCompleted = nextVal >= habit.targetCount

        val log = HabitLogEntity(
            id = currentLog?.id ?: 0,
            habitId = habitId,
            date = date,
            status = if (isCompleted) "COMPLETED" else "IN_PROGRESS",
            value = nextVal,
            completedAt = System.currentTimeMillis()
        )
        habitLogDao.insertLog(log)
        syncRepository?.syncLogUp(currentUserId, log)

        recalculateStreak(habit)
        return isCompleted
    }

    suspend fun decrementHabitValue(habitId: Long, date: String) {
        if (DateUtils.isFutureDate(date)) return
        val habit = habitDao.getHabitById(habitId) ?: return
        val currentLog = habitLogDao.getLogForHabitAndDate(habitId, date) ?: return

        val nextVal = (currentLog.value - 1).coerceAtLeast(0)
        if (nextVal == 0) {
            habitLogDao.deleteLog(habitId, date)
            syncRepository?.deleteLogRemote(currentUserId, habitId, date)
        } else {
            val isCompleted = nextVal >= habit.targetCount
            val log = currentLog.copy(
                status = if (isCompleted) "COMPLETED" else "IN_PROGRESS",
                value = nextVal
            )
            habitLogDao.insertLog(log)
            syncRepository?.syncLogUp(currentUserId, log)
        }

        recalculateStreak(habit)
    }

    suspend fun setHabitStatus(habitId: Long, date: String, status: String) {
        if (DateUtils.isFutureDate(date)) return
        val habit = habitDao.getHabitById(habitId) ?: return
        val currentLog = habitLogDao.getLogForHabitAndDate(habitId, date)

        val log = HabitLogEntity(
            id = currentLog?.id ?: 0,
            habitId = habitId,
            date = date,
            status = status,
            value = if (status == "COMPLETED" || status == "GRACE") habit.targetCount else 0,
            completedAt = System.currentTimeMillis()
        )
        habitLogDao.insertLog(log)
        syncRepository?.syncLogUp(currentUserId, log)

        recalculateStreak(habit)
    }

    suspend fun undoHabit(habitId: Long, date: String) {
        val habit = habitDao.getHabitById(habitId) ?: return
        habitLogDao.deleteLog(habitId, date)
        syncRepository?.deleteLogRemote(currentUserId, habitId, date)
        recalculateStreak(habit)
    }

    suspend fun createHabit(habit: HabitEntity): Long {
        val scoped = habit.copy(
            userId = if (habit.userId.isBlank() || habit.userId == "user_default") currentUserId else habit.userId,
            startDate = if (habit.startDate.isNotBlank()) habit.startDate else DateUtils.getTodayString()
        )
        val id = habitDao.insertHabit(scoped)
        val persistedHabit = scoped.copy(id = id)
        userStreakDao.upsertStreak(
            UserStreakEntity(habitId = id)
        )
        syncRepository?.syncHabitUp(persistedHabit)
        return id
    }

    suspend fun updateHabit(habit: HabitEntity) {
        val scoped = if (habit.userId.isBlank() || habit.userId == "user_default") {
            habit.copy(userId = currentUserId)
        } else {
            habit
        }
        habitDao.updateHabit(scoped)
        syncRepository?.syncHabitUp(scoped)
        recalculateStreak(scoped)
    }

    suspend fun deleteHabit(habitId: Long) {
        habitDao.deleteHabit(habitId)
        habitLogDao.deleteAllLogsForHabit(habitId)
        userStreakDao.deleteStreak(habitId)
        syncRepository?.deleteHabitRemote(currentUserId, habitId)
    }

    suspend fun archiveHabit(habitId: Long) {
        habitDao.archiveHabit(habitId)
        val habit = habitDao.getHabitById(habitId)
        if (habit != null) {
            syncRepository?.syncHabitUp(habit.copy(archived = true))
        }
    }

    private suspend fun recalculateStreak(habit: HabitEntity) {
        val logs = habitLogDao.getLogsListForHabit(habit.id)
        val streak = SmartStreakEngine.calculateStreak(habit, logs)
        userStreakDao.upsertStreak(streak)
        syncRepository?.syncStreakUp(currentUserId, streak)
    }

    fun getAnalyticsSummary(): Flow<AnalyticsSummary> {
        val habitsFlow = if (authRepository != null) {
            authRepository.currentUser.flatMapLatest { user ->
                val uid = user?.id ?: "guest"
                habitDao.getActiveHabits(uid)
            }
        } else {
            habitDao.getActiveHabits()
        }

        return combine(
            habitsFlow,
            habitLogDao.getAllLogs(),
            userStreakDao.getAllStreaksFlow(),
            userSettingsDao.getSettingsFlow()
        ) { habits, logs, streaks, settings ->
            val logsByHabit = logs.groupBy { it.habitId }
            val logsByDate = logs.groupBy { it.date }
            val streaksByHabit = streaks.associateBy { it.habitId }
            val today = DateUtils.getTodayString()
            val currentMonth = today.substring(0, 7)
            val graceLimit = settings?.graceDaysPerMonth ?: 2

            val totalCompletionsAllTime = logs.count { it.status == "COMPLETED" }

            val heatmapDays = mutableListOf<HeatmapDay>()
            var perfectDays = 0
            var totalDue30Days = 0
            var completed30Days = 0

            for (i in 89 downTo 0) {
                val date = DateUtils.addDays(today, -i)
                val dayLogs = logsByDate[date] ?: emptyList()
                val activeDueCount = habits.count { SchedulingEngine.isHabitDueOnDate(it, date) }
                val completedCount = dayLogs.count { it.status == "COMPLETED" }
                val ratio = if (activeDueCount > 0) (completedCount.toFloat() / activeDueCount).coerceIn(0f, 1f) else 0f
                val isPerfect = activeDueCount > 0 && completedCount >= activeDueCount

                if (isPerfect) perfectDays++

                if (i < 30) {
                    totalDue30Days += activeDueCount
                    completed30Days += completedCount
                }

                heatmapDays.add(
                    HeatmapDay(
                        date = date,
                        dayOfWeek = DateUtils.getDayOfWeek(date),
                        completionRatio = ratio,
                        completedCount = completedCount,
                        totalDueCount = activeDueCount,
                        isToday = DateUtils.isToday(date)
                    )
                )
            }

            // Weekday stats
            val weekdayCounts = mutableMapOf<String, Pair<Int, Int>>() // Day -> Completed, TotalDue
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                weekdayCounts[day] = Pair(0, 0)
            }

            heatmapDays.takeLast(28).forEach { hDay ->
                val dayName = DateUtils.getDayOfWeekShort(hDay.dayOfWeek)
                val current = weekdayCounts[dayName] ?: Pair(0, 0)
                weekdayCounts[dayName] = Pair(current.first + hDay.completedCount, current.second + hDay.totalDueCount)
            }

            val weekdayStats = weekdayCounts.map { (day, counts) ->
                val percentage = if (counts.second > 0) ((counts.first.toFloat() / counts.second) * 100).toInt() else 0
                WeekdayStat(
                    dayName = day,
                    completionPercentage = percentage,
                    totalLogs = counts.second,
                    completedLogs = counts.first
                )
            }

            val topHabits = habits.map { habit ->
                val habitLogs = logsByHabit[habit.id] ?: emptyList()
                val streak = streaksByHabit[habit.id]
                val completedIn30 = habitLogs.count {
                    it.status == "COMPLETED" && it.date >= DateUtils.addDays(today, -30)
                }
                val dueIn30 = (0..29).count { i ->
                    val d = DateUtils.addDays(today, -i)
                    SchedulingEngine.isHabitDueOnDate(habit, d)
                }.coerceAtLeast(1)

                val rate = (completedIn30.toFloat() / dueIn30).coerceIn(0f, 1f)

                HabitPerformance(
                    habitId = habit.id,
                    habitName = habit.name,
                    category = habit.category,
                    colorHex = habit.colorHex,
                    iconName = habit.iconName,
                    currentStreak = streak?.currentStreak ?: 0,
                    longestStreak = streak?.longestStreak ?: 0,
                    completionRate = rate,
                    totalCompletions = habitLogs.count { it.status == "COMPLETED" }
                )
            }.sortedByDescending { it.completionRate }

            val currentBestStreak = streaks.maxOfOrNull { it.currentStreak } ?: 0

            val graceUsedThisMonth = logs.count {
                it.status == "GRACE" && it.date.startsWith(currentMonth)
            }

            val overallConsistency = if (totalDue30Days > 0) {
                ((completed30Days.toFloat() / totalDue30Days) * 100).toInt()
            } else {
                0
            }

            val monthDelta = if (overallConsistency > 0) 5 else 0

            val insights = InsightsEngine.generateInsights(
                habits = habits,
                logs = logs,
                weekdayStats = weekdayStats,
                overallConsistency = overallConsistency,
                graceDaysUsed = graceUsedThisMonth,
                graceDaysLimit = graceLimit
            )

            AnalyticsSummary(
                overallConsistency = overallConsistency,
                monthDelta = monthDelta,
                totalCompletionsAllTime = totalCompletionsAllTime,
                perfectDaysCount = perfectDays,
                activeHabitsCount = habits.size,
                currentBestStreak = currentBestStreak,
                graceDaysUsedThisMonth = graceUsedThisMonth,
                graceDaysLimit = graceLimit,
                heatmapDays = heatmapDays,
                weekdayStats = weekdayStats,
                topHabits = topHabits,
                insights = insights
            )
        }
    }

    suspend fun clearAllUserData() {
        val uid = currentUserId
        habitDao.deleteAllHabitsForUser(uid)
    }

    suspend fun seedStarterHabitsForUser(userId: String = currentUserId) {
        val starters = listOf(
            HabitEntity(
                userId = userId,
                name = "Morning Hydration",
                description = "Drink fresh water upon waking",
                category = "Health",
                iconName = "water_drop",
                colorHex = "#B6FF00",
                frequencyType = "DAILY",
                targetCount = 1,
                unit = "time",
                timeOfDay = "MORNING"
            ),
            HabitEntity(
                userId = userId,
                name = "Mindful Breathing",
                description = "5 to 10 minutes of silent breathwork",
                category = "Mind",
                iconName = "brain",
                colorHex = "#A855F7",
                frequencyType = "DAILY",
                targetCount = 1,
                unit = "time",
                timeOfDay = "MORNING"
            ),
            HabitEntity(
                userId = userId,
                name = "Deep Focus Block",
                description = "High-priority uninterrupted work",
                category = "Focus",
                iconName = "code",
                colorHex = "#00E5FF",
                frequencyType = "WEEKDAYS",
                targetCount = 1,
                unit = "session",
                timeOfDay = "AFTERNOON"
            )
        )

        for (starter in starters) {
            createHabit(starter)
        }
    }
}
