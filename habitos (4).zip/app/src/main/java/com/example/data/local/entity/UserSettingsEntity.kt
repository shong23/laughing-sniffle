package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val userId: String = "user_default",
    val themeMode: String = "SYSTEM", // DARK, LIGHT, SYSTEM
    val accentColor: String = "#B6FF00",
    val graceDaysPerMonth: Int = 2,
    val hapticsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val weekStartMonday: Boolean = true,
    val onboardingCompleted: Boolean = false,
    val reminderNotifications: Boolean = true
)

